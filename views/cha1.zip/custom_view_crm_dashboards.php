<?php $_SESSION['apply_js']['multiselest'] = 1; 
$_SESSION['apply_js']['ratting'] = 1;
//$leadsourceary = array("1"=>"Self","2"=>"Facebok","3"=>"Instagram","4"=>"Linkdin");
$status = array("0"=>"Active","101"=>"Approve-1","102"=>"Approve-2","199"=>"Approve");
$menu = CRMAPI."?mode=getcrmleads&list=Y"; 
$page_list = callAPI($menu);
$result = json_decode($page_list,1);
//$today_crm_lead_details = $result['today_crm_lead_details'];
//echo "<pre>"; print_r($result['today_crm_lead_details']);echo "</pre>";
$crm_leads = $result['crm_leads'];
$crm_contacts = $result['crm_contacts'];
$crm_companies = $result['crm_companies'];
$crm_source_type = $result['crm_source_types'];
$crm_source_types = array();
foreach($crm_source_type as $crmsource){
	$crm_source_types[$crmsource['id']] = $crmsource['source_name']; 
}
// $leadcode = array();
// foreach($crm_leadslist as $crm_leads){
// 	$leadcode[$crm_leads['id']] = $crm_leads['lead_code']; 
// }
// $crm_lead_types =$res['crm_lead_types']; 
// $crmleaddetailstypes = array();
// foreach($crm_lead_types as $crmlt){
//     if($crmlt['type'] == 2){
//         $crmleaddetailstypes[$crmlt['id']] =$crmlt;
//     } 
// }
// $lastactivity_crm_lead_details =$result['lastactivity_crm_lead_details'];
// foreach($lastactivity_crm_lead_details as $lastactcrllead){
// 	$lastactivity[$lastactcrllead['crm_lead_id']]=$lastactcrllead;
// }
//print_r($lastactivity);
?>
<script type="text/javascript">
    function leadPageCall(crm_tab_type,rid=""){
    	var loader = '<div class="text-center" id="loader-show"><img src="assets/images/spiner/spiner3.gif" style="width: 300px;"></div>';
    	$("#htmlsetpage").html(loader);
    	var url = "";
    	if(crm_tab_type == "LEAD"){
    		url = "custom_insert_crm_leads.php";
    	}else if(crm_tab_type == "CONTACT"){
    		url = "custom_insert_crm_contacts.php";
    	}else if(crm_tab_type == "COMPANY"){
    		url = "custom_insert_crm_companies.php";
    	}
        jQuery.ajax({
            url: "views/"+url,
            data: "rid="+rid,
            type: "POST",
            success:function(data){
                $('#htmlsetpage').html(data);
                $(".js-example-basic-single").select2();
				$(".js-example-basic-multiple").select2();
                $(".datepicker" ).datepicker({
					showOn: "both",
					buttonText: "<i class='ti-calendar text-dark f-20 f-w-800 m-r-10'></i>",
					dateFormat: DateFormate,
					changeMonth: true,
					changeYear: true
				});
            }
        });
    }
    function crmupdatestatus(status,crm_lead_id){
    	console.log(status+" -- "+crm_lead_id);
    	var transaction_table = "crm_leads";
    	jQuery.ajax({
            url: "ajax.php",
            data: "page=dynamicupdatestatus&current_status="+status+"&rid="+crm_lead_id+"&transaction_table="+transaction_table,
            type: "POST",
            success:function(data){
                console.log(data);
                var jsonres = JSON.parse(data);
                console.log(jsonres.res.status);
                if(jsonres.res.status == "sucess"){
                    tostarnotify('top','right','fa fa-thumbs-up','form-label label label-success','animated flipInX','animated flipOutX','<?php echo $_SESSION['error_message']['3000']; ?>','');
                }else{
                    tostarnotify('top','right','fa fa-thumbs-down','form-label label label-danger','animated flipInX','animated flipOutX',jsonres.res.message,'');
                }
            }
        });

    }
</script>
<!-- <ul class="nav md-tabs infisuite_tab mb-3" role="tablist">
	<li class="nav-item">
		<a class="nav-link f-w-600 f-12 active" data-bs-toggle="tab" href="#itemcategory" role="tab" aria-selected="true">Leads<label class="form-label label label-xs label-success m-l-10"><?php echo count((array)$crm_leadslist); ?></label></a>
	</li>
	<li class="nav-item">
		<a class="nav-link f-w-600 f-12" data-bs-toggle="tab" href="#itemlocation" role="tab" aria-selected="true">Deals<label class="form-label label label-xs label-success m-l-10">0</label></a>
	</li>
	<li class="nav-item">
		<a class="nav-link f-w-600 f-12" data-bs-toggle="tab" href="#costcenter" role="tab" aria-selected="true">Contact<label class="form-label label label-xs label-success m-l-10">0</label></a>
	</li>
	<li class="nav-item">
		<a class="nav-link f-w-600 f-12" data-bs-toggle="tab" href="#costcenter" role="tab" aria-selected="true">Companies<label class="form-label label label-xs label-success m-l-10">0</label></a>
	</li>
</ul>
 -->
<div class="card product-progress-card mb-3">
    <div class="card-block">
        <div class="row ">
            <div class="col-lg-5">
                <div class="d-flex">
                <div class="flex-shrink-0 m-r-30 m-l-25 mt-lg-0 mt-3">
                    <?php if($_SESSION['user']['user_photo']!=""){ ?>
                    <div class="symbol symbol-50 symbol-lg-120">
                      <img src="../uploads/all/<?php echo $_SESSION['user']['user_photo']; ?>" class="img-120 " alt="image" onerror="this.src='uploads/all/no-image.jpg';"/>
                    </div>

                  <?php }else{ ?>
                    <div class="symbol symbol-50 symbol-lg-120">
                      <img src="../uploads/all/<?php echo $_SESSION['employee']['gender'].".png"; ?>" class="img-120 " alt="image" onerror="this.src='uploads/all/no-image.jpg';"/>
                    </div>
                  <?php } ?>
                    <div class="d-flex align-items-center w-100px w-sm-120px flex-column mt-3 ">
                        <div class="d-flex justify-content-between w-100 mt-auto mb-2">
                          <span class="f-12 f-w-600">Leads </span>
                          <span class="f-12 f-w-600"><?php echo $totaltaskper; ?>%</span>
                        </div>
                        <div class="col-md-12">
                          <div class="progress progress-xs">
                            <div class="progress-bar progress-bar-success" role="progressbar" style="width:<?php echo $totaltaskper; ?>%;" aria-valuenow=" " aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center w-100px w-sm-120px flex-column mt-3 ">
                        <div class="d-flex justify-content-between w-100 mt-auto mb-2">
                          <span class="f-12 f-w-600">Contacts </span>
                          <span class="f-12 f-w-600"><?php echo $totaltaskper; ?>%</span>
                        </div>
                        <div class="col-md-12">
                          <div class="progress progress-xs">
                            <div class="progress-bar progress-bar-success" role="progressbar" style="width:<?php echo $totaltaskper; ?>%;" aria-valuenow=" " aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                        </div>
                    </div>
                </div>
                <div class="flex-grow-1">
                    <div class="d-flex justify-content-between flex-wrap mt-1">
                        <div class="d-flex mr-3">
                            <span class="text-dark-75 text-hover-primary font-size-h5 font-weight-bold mr-3 f-16 f-w-600"><?php echo $_SESSION['user']['display_name']; ?></span>
                        </div>
                    </div>
                    <div class="">
                        <div class="d-flex flex-wrap justify-content-between mt-1 ">
                            <div class="d-flex flex-column flex-grow-1 pr-8  ">
                                <div class="d-flex flex-wrap mb-2 mt-2">
                                    <a href="#" class="text-dark-50 text-hover-primary font-weight-bold mr-lg-8 mr-5 mb-lg-0 mb-2 m-l-5">
                                    <i class="ti-email f-14 text-primary"></i>&nbsp;  <?php echo $_SESSION['user']['user_email']; ?></a>
                                </div>
                            </div>
                            <input type="hidden" id="location_id" value="">
                            <input type="hidden" id="start_date" value="2023-08-11">
                        </div>
                    </div>
                </div>
              </div>
            </div> 
            <div class="col-lg-7" >
            <div class="col-lg-12" >
                <div class="row">
                    <div class="col-xl-4 col-md-6">
                        <div class="card social-card">
                            <div class="card-body text-center p-0">
                                <h2 class="text-facebook m-b-5"><i class="ti-user f-24 text-mute"></i></h2>
                                <h3 class="text-facebook f-w-700"><?php echo count((array)$crm_leads); ?></h3>
                                <p>Total Leads</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 ">
                        <div class="card social-card">
                            <div class="card-body text-center p-0">
                                <h2 class="text-facebook m-b-5"><i class="ti-user f-24 text-mute"></i></h2>
                                <h3 class="text-facebook f-w-700"><?php echo count((array)$crm_contacts); ?></h3>
                                <p>Total Contacts</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6">
                        <div class="card social-card">
                            <div class="card-body text-center p-0">
                                <h2 class="text-facebook m-b-5"><i class="ti-user f-24 text-mute"></i></h2>
                                <h3 class="text-facebook f-w-700"><?php echo count((array)$crm_companies); ?></h3>
                                <p>Total Companies</p>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>
            <div class="col-lg-12">
                <div class="row mt-4">
                     <div class="col-1 text-center"></div>
                    <div class="col-2 text-center">
                        <div class="s-caption  text-primary"><i class="ti-list f-20"></i></div>
                        <div class="s-cont d-inline-block">
                            <h5 class="f-w-700 m-b-0"><?php echo $totaltask; ?></h5>
                            <p class="m-b-0 f-12">Total Task</p>
                        </div>
                    </div>
                    <div class="col-2 b-l-default text-center">
                        <div class="s-caption  text-danger"><i class="ti-time f-20"></i></div>
                        <div class="s-cont d-inline-block">
                            <h5 class="f-w-700 m-b-0"><?php echo $totalyettostartcnttask; ?></h5>
                            <p class="m-b-0 f-12">Yet To Start</p>
                        </div>
                    </div>
                    <div class="col-2 b-l-default text-center">
                        <div class="s-caption  text-info"><i class="ti-timer f-20"></i></div>
                        <div class="s-cont d-inline-block">
                            <h5 class="f-w-700 m-b-0"><?php echo $totalinprogresstask; ?></h5>
                            <p class="m-b-0  f-12">In Progress</p>
                        </div>
                    </div>
                    <div class="col-2 b-l-default text-center">
                        <div class="s-caption  text-info"><i class="ti-write f-20"></i></div>
                        <div class="s-cont d-inline-block">
                            <h5 class="f-w-700 m-b-0"><?php echo $totalreviewpendingtask; ?></h5>
                            <p class="m-b-0 f-12">Review</p>
                        </div>
                    </div>
                    <div class="col-2 b-l-default text-center">
                        <div class="s-caption  text-success"><i class="ti-check-box f-20"></i></div>
                        <div class="s-cont d-inline-block">
                            <h5 class="f-w-700 m-b-0"><?php echo $totalapprovedtask; ?></h5>
                            <p class="m-b-0 f-12">Completed</p>
                        </div>
                    </div>
                    <div class="col-1 text-center"></div>
                    <!-- <div class="col-2 b-l-default text-center">
                        <div class="s-caption  text-danger"><i class="ti-pulse f-20"></i></div>
                        <div class="s-cont d-inline-block">
                            <h5 class="f-w-700 m-b-0 text-danger"><?php echo 0; ?></h5>
                            <p class="m-b-0 f-12 text-danger">Delayed Task</p>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
        </div>  
    </div>
</div>

<div class="row">
	<div class="col-lg-9">
		<ul class="nav md-tabs infisuite_tab mb-3" role="tablist">
			<li class="nav-item">
				<a class="nav-link f-w-600 f-12 active" data-bs-toggle="tab" href="#lead-tab" role="tab" aria-selected="true">Leads<label class="form-label label label-xs label-success m-l-10"><?php echo count((array)$crm_leads); ?></label></a>
			</li>
			<li class="nav-item">
				<a class="nav-link f-w-600 f-12" data-bs-toggle="tab" href="#contact-tab" role="tab" aria-selected="true">Contacts<label class="form-label label label-xs label-success m-l-10"><?php echo count((array)$crm_contacts); ?></label></a>
			</li> 
			<li class="nav-item">
				<a class="nav-link f-w-600 f-12" data-bs-toggle="tab" href="#company-tab" role="tab" aria-selected="true">Companies<label class="form-label label label-xs label-success m-l-10"><?php echo count((array)$crm_companies); ?></label></a>
			</li>
			<li class="nav-item">
				<a class="nav-link f-w-600 f-12" data-bs-toggle="tab" href="#deal-tab" role="tab" aria-selected="true">Deals<label class="form-label label label-xs label-success m-l-10">0</label></a>
			</li>
		</ul>
		<div class="tab-content tabs">
			<div class="tab-pane card-body p-0 active" id="lead-tab" role="tabpanel">	
				<div class="card">
					<div class="card-header">
						<h5>Leads</h5>
						<div class="card-header-right">                           
							<button type="button" class="btn btn-success mb-2 desktop-view leadsidebar "  onclick="leadPageCall('LEAD')"><i class="icofont icofont-plus icon-white "></i> Leads </button>
						</div>
					</div>
					<div class="card-body">
						<?php if(count((array)$crm_leads) !=0){ ?>
						<table class="table table-hover m-b-0" style="font-size:13px;" id="categoryfilter">
							<thead>
								<tr><th>Name</th>
									<th>Contact</th>				
									<th>Originator</th>
									<th>Source</th>
									<th>Last Action</th>
								</tr>
							</thead>
							<tbody>
							<?php foreach($crm_leads as $crmleads){ ?>	    
								<tr>
									<td>
										<a href="#!" class="leadsidebar text-primary" onclick="leadPageCall('LEAD','<?php echo $crmleads['id']; ?>')"><?php echo $crmleads['display_name']; ?></a>
									</td>
									<td ><?php echo $crmleads['phone']; ?></td>
									<td ><?php echo $_SESSION['users'][$crmleads['originator']]; ?></td>
									<td ><?php echo $crm_source_types[$crmleads['contact_source']]; ?></td>
									<td class="w-b-w-s"><?php echo "-"; ?></td>
								</tr>
							<?php } ?>
							</tbody>
						</table>
					<?php }else{ ?>
						<div class="card-px text-center ">
							<p class="text-muted f-16 fw-bold m-b-30"><i class="ti ti-alert text-warning"></i> No Leads</p>   
							<div class="text-center px-4">
								<img class="mw-100 mh-300px" alt="" src="assets/images/work.png" style="max-height: 300px!important;">
							</div>   
						</div>
					<?php } ?>
					</div>
				</div>
			</div>
			













			<div class="tab-pane card-body p-0" id="contact-tab" role="tabpanel">	
					<div class="card">
						<div class="card-header">
							<h5>Contacts</h5>
							<div class="card-header-right">                           
								<button type="button" class="btn btn-success mb-2 desktop-view leadsidebar "  onclick="leadPageCall('CONTACT')"><i class="icofont icofont-plus icon-white "></i> Contact </button>
							</div>
						</div>
						<div class="card-body">
							<?php if(count((array)$crm_contacts) !=0){ ?>
							<table class="table table-hover m-b-0" style="font-size:13px;" id="categoryfilter">
								<thead>
									<tr><th>Name</th>
										<th>Number</th>				
										<th>Originator</th>
										<th>Source</th>
										<th>Last Action</th>
									</tr>
								</thead>
								<tbody>
					                <?php foreach($crm_contacts as $crmleads){
					                	// $crmld = $lastactivity[$crmleads['id']];
					                	// $meg = $crmld['max_updated_date']." ";
					                 //    if($crmld['lead_type'] == '2' || $crmld['lead_type'] == '3'){
					                 //        $meg .= "<span class='d-block'>".$crmld['date']." ".$crmld['time']."</span>".$crmld['comment'];
					                 //    }elseif($crmld['lead_type'] == '4'){
					                 //        $meg = "<span class='d-block'>".$crmld['phone']." ".$crmld['time']."</span>".$crmld['sms_text'];
					                 //    }elseif($crmld['lead_type'] == '5'){
					                 //        $meg .= "<span class='d-block'>".$crmld['recipient_email_id']."</span>".$crmld['sms_text'];
					                 //    }elseif($crmld['lead_type'] == '7'){ //meeting
					                 //        $member = json_decode($crmld['member'],1);
					                 //            //($member);
					                 //            $membermsg = "";
					                 //            foreach($member as $members){
					                 //                $membermsg .= "<span class='m-r-5'>".$_SESSION['users'][$members].",</span>";
					                 //            }
					                 //        $meg .= "<span class='d-block'>".$crmld['date']." ".$crmld['time']."</span>".$membermsg." <span class='d-block'>".$crmld['comment']."</span>";
					                 //    }elseif($crmld['lead_type'] == '8'){ //visit
					                 //         $meg .= "<span class='d-block'>".$crmld['date']." ".$crmld['time']."</span>";
					                 //         $meg .= "<span class='d-block'>".$crmld['address']." ".$crmld['post_code']."</span>";
					                 //         $meg .=$crmld['comment'];
					                 //    }else{
					                 //         $meg .= $crmld['comment'] !=""?$crmld['comment']:"-";
					                 //    }

					                 //    if(!isset($crmld['comment'])){
					                 //    	$meg = $crmleads['created_date']." Created Lead";
					                 //    }
					                	?>
									<tr>
										<td>
											<a href="#!" class="leadsidebar text-primary" onclick="leadPageCall('CONTACT','<?php echo $crmleads['id']; ?>')"><?php echo $crmleads['display_name']; ?></a>
										</td>
										<td ><?php echo $crmleads['phone']; ?></td>
										<td ><?php echo $_SESSION['users'][$crmleads['originator']]; ?></td>
										<td ><?php echo $crm_source_types[$crmleads['contact_source']]; ?></td>
										<td class="w-b-w-s"><?php echo $meg; ?></td>
									</tr>
								<?php } ?>
								</tbody>
							</table>
						<?php }else{ ?>
							<div class="card-px text-center ">
								<p class="text-muted f-16 fw-bold m-b-30"><i class="ti ti-alert text-warning"></i> No Contacts</p>   
								<div class="text-center px-4">
									<img class="mw-100 mh-300px" alt="" src="assets/images/work.png" style="max-height: 300px!important;">
								</div>   
							</div>
						<?php } ?>
						</div>
					</div>		
			</div>
			








			<div class="tab-pane card-body p-0" id="company-tab" role="tabpanel">	
				<div class="card">
					<div class="card-header">
						<h5>Companies</h5>
						<div class="card-header-right">                           
							<button type="button" class="btn btn-success mb-2 desktop-view leadsidebar "  onclick="leadPageCall('COMPANY')"><i class="icofont icofont-plus icon-white "></i> Company </button>
						</div>
					</div>
					<div class="card-body">
						<?php if(count((array)$crm_companies) !=0){ ?>
							<table class="table table-hover m-b-0" style="font-size:13px;" id="categoryfilter">
								<thead>
									<tr><th>Company Name</th>
										<th>Originator</th>
										<th>Website URL</th>				
										<th>Address</th>
									</tr>
								</thead>
								<tbody>
					                <?php foreach($crm_companies as $companiesres){
					                	?>
									<tr>
										<td>
											<a href="#!" class="leadsidebar text-primary" onclick="leadPageCall('COMPANY','<?php echo $companiesres['id']; ?>')"><?php echo $companiesres['company_name']; ?></a>
										</td>
										<td ><?php echo $_SESSION['users'][$companiesres['originator']]; ?></td>
										<td ><?php echo $companiesres['website_url']; ?></td>
										<td ><?php echo $companiesres['address']; ?></td>
									</tr>
								<?php } ?>
								</tbody>
							</table>
						<?php }else{ ?>
							<div class="card-px text-center ">
								<p class="text-muted f-16 fw-bold m-b-30"><i class="ti ti-alert text-warning"></i> No Companies</p>   
								<div class="text-center px-4">
									<img class="mw-100 mh-300px" alt="" src="assets/images/work.png" style="max-height: 300px!important;">
								</div>   
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
			<div class="tab-pane card-body p-0" id="deal-tab" role="tabpanel">	
				deal
			</div>

		</div>
	</div>
	<div class="col-lg-3 text-right">
		<button type="button" class="btn btn-primary waves-effect waves-light m-r-10" ><i class="ti-list"></i> List</button>
		<button type="button" class="btn btn-primary waves-effect waves-light" ><i class="ti-layout-column4-alt"></i> Kanban board</button>

		<div class="card">
			<div class="card-header">
				<h5>Today Activity</h5>
			</div>
			<div class="card-body">
				<table class="table table-hover m-b-0" style="font-size:13px;" >
					<thead>
						<tr><th>Lead Code</th>
							<th>Activity</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($today_crm_lead_details as $crmld){ 
							$meg = "";
		                    if($crmld['lead_type'] == '2' || $crmld['lead_type'] == '3'){
		                        $meg .= "<span class='d-block'>".$crmld['date']." ".$crmld['time']."</span>".$crmld['comment'];
		                    }elseif($crmld['lead_type'] == '4'){
		                        $meg = "<span class='d-block'>".$crmld['phone']." ".$crmld['time']."</span>".$crmld['sms_text'];
		                    }elseif($crmld['lead_type'] == '5'){
		                        $meg .= "<span class='d-block'>".$crmld['recipient_email_id']."</span>".$crmld['sms_text'];
		                    }elseif($crmld['lead_type'] == '7'){ //meeting
		                        $member = json_decode($crmld['member'],1);
		                            //($member);
		                            $membermsg = "";
		                            foreach($member as $members){
		                                $membermsg .= "<span class='m-r-5'>".$_SESSION['users'][$members].",</span>";
		                            }
		                        $meg .= "<span class='d-block'>".$crmld['date']." ".$crmld['time']."</span>".$membermsg." <span class='d-block'>".$crmld['comment']."</span>";
		                    }elseif($crmld['lead_type'] == '8'){ //visit
		                         $meg .= "<span class='d-block'>".$crmld['date']." ".$crmld['time']."</span>";
		                         $meg .= "<span class='d-block'>".$crmld['address']." ".$crmld['post_code']."</span>";
		                         $meg .=$crmld['comment'];
		                    }else{
		                         $meg .= $crmld['comment'] !=""?$crmld['comment']:"-";
		                    }
							?>
							<tr>
								<td><?php echo $leadcode[$crmld['crm_lead_id']]; ?></td>
								<td class="w-b-w-s"><?php echo $meg; ?></td>
							</tr>
					<?php } ?>
					</tbody>
				</table>
		        
			</div>
		</div>
	</div>
</div>

<!---------Add Lead Form------------->
<div id="sidebar" class="users p-chat-user leadsidebar-form text-left">
    <div class="had-container">
        <div class="p-fixed users-main " id="htmlsetpage" >
            
        </div>
    </div>
</div>