<?php
if ($_POST['ajaxcall'] == "Y") {
    include('../includes/session.php');
    include('../dbconfig.php');
    include('../comm.php');
}

function showNotificationIcon($status)
{
    if ($status == 'verified') {
        return '<i class="fa fa-check text-success"></i>';
    } elseif ($status == 'error') {
        return '<i class="fa fa-times text-danger"></i>';
    } elseif ($status == 'warning') {
        return '<i class="fa fa-exclamation-triangle text-warning"></i>';
    }
    return '<i class="fa fa-clock-o text-muted"></i>';
}

// Define variables needed for JavaScript data containers
$visible_document_verifications = ['PAN', 'GSTIN', 'BANK', 'TAN', 'MSME'];

// Initialize vendor_verifications if not set
if (!isset($vendor_verifications)) {
    $vendor_verifications = [];
}

// Parse vendor verifications if it's a JSON string
if (isset($vendordetail['vendor_verifications']) && !empty($vendordetail['vendor_verifications'])) {
    $vendor_verifications = json_decode($vendordetail['vendor_verifications'], true);
    if (!is_array($vendor_verifications)) {
        $vendor_verifications = [];
    }
} else {
    $vendor_verifications = [];
}
?>

<link rel="stylesheet" type="text/css" href="./assets/css/custom_insert_vendors_and_vendor_registers_verifications.css">

<div class="verification-container">
    <!-- PHP Data Containers for JavaScript -->
    <div class="php-data-container" style="display: none;">
        <div class="vendor-id-data"><?php echo $vendor_id ?? ''; ?></div>
        <div class="transaction-table-data"><?php echo $transaction_table ?? ''; ?></div>
        <div class="required-verifications-data"><?php echo json_encode($required_document_verifications ?? []); ?></div>
        <div class="visible-verifications-data"><?php echo json_encode($visible_document_verifications); ?></div>
        <div class="vendor-verifications-data"><?php echo json_encode($vendor_verifications); ?></div>
        <div class="vendor-detail-email-data"><?php echo $vendordetail['email'] ?? ''; ?></div>
        <div class="vendor-detail-company-data"><?php echo $vendordetail['company'] ?? ''; ?></div>
        <div class="session-error-3001-data"><?php echo $_SESSION['error_message']['3001'] ?? ''; ?></div>
        <div class="session-error-3000-data"><?php echo $_SESSION['error_message']['3000'] ?? ''; ?></div>
    </div>
    
    <!-- Notification Container -->
    <div id="notification-container"></div>
    <!-- Step Indicator -->
    <div class="step-indicator">
        <?php
        $step_mapping = [
            'PAN' => ['title' => 'PAN', 'icon' => 'fa-id-card'],
            'GSTIN' => ['title' => 'GST', 'icon' => 'fa-building'],
            'BANK' => ['title' => 'Bank', 'icon' => 'fa-university'],
            'MSME' => ['title' => 'MSME', 'icon' => 'check'],
            'TAN' => ['title' => 'TAN', 'icon' => 'fa-file-text']
        ];

        $step_counter = 1;
        $first_incomplete_step = null;

        foreach ($visible_document_verifications as $verification_type) {
            if (isset($step_mapping[$verification_type])) {
                // Check if this verification is already completed
                $is_verified = isset($vendor_verifications[$verification_type]['status']) &&
                    $vendor_verifications[$verification_type]['status'] == 'Y';

                // Determine step class
                $step_class = '';
                if ($is_verified) {
                    $step_class = 'completed';
                } elseif ($first_incomplete_step === null) {
                    $step_class = 'active';
                    $first_incomplete_step = $step_counter;
                }

                echo '<div class="step ' . $step_class . ' step-indicator-item" data-step="' . $step_counter . '">';
                echo '<div class="step-number">';
                if ($is_verified) {
                    echo '<i class="fa fa-check"></i>';
                } else {
                    echo $step_counter;
                }
                echo '</div>';
                $mandatory_indicator = in_array($verification_type, $required_document_verifications) ? ' <span class="text-danger">*</span>' : '';
                echo '<div class="step-title">' . $step_mapping[$verification_type]['title'] . $mandatory_indicator . '</div>';
                echo '</div>';
                $step_counter++;
            }
        }
        ?>
    </div>

    <?php
    // Generate verification steps dynamically
    $step_counter = 1;
    $first_incomplete_step = null;

    // Find first incomplete step
    foreach ($visible_document_verifications as $verification_type) {
        $is_verified = isset($vendor_verifications[$verification_type]['status']) &&
            $vendor_verifications[$verification_type]['status'] == 'Y';
        if (!$is_verified && $first_incomplete_step === null) {
            $first_incomplete_step = $step_counter;
        }
        $step_counter++;
    }

    $step_counter = 1;
    foreach ($visible_document_verifications as $verification_type) {
        // Check verification status
        $is_verified = isset($vendor_verifications[$verification_type]['status']) &&
            $vendor_verifications[$verification_type]['status'] == 'Y';

        $active_class = '';
        if ($is_verified) {
            $active_class = 'completed';
        } elseif ($step_counter == $first_incomplete_step) {
            $active_class = 'active';
        }

        if ($verification_type == 'PAN') {
            ?>
            <!-- Step <?php echo $step_counter; ?>: PAN Verification -->
            <div id="step-<?php echo $step_counter; ?>" class="verification-step <?php echo $active_class; ?>">
                <div class="step-header">
                    <?php if ($is_verified): ?>
                        <h3><i class="fa fa-check-circle text-success"></i> PAN Card Verification - Completed</h3>
                        <p class="text-success">Your PAN has been successfully verified on
                            <?php echo date('d M Y, h:i A', strtotime($vendor_verifications['PAN']['verification_datetime'])); ?>
                        </p>
                    <?php else: ?>
                        <h3><i class="fa fa-id-card text-primary"></i> PAN Card Verification <?php echo in_array('PAN', $required_document_verifications) ? '<span class="text-danger">*</span>' : ''; ?></h3>
                        <p>Enter your PAN card number to verify your identity and business details</p>
                    <?php endif; ?>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <?php if ($is_verified): ?>
                            <!-- Verified PAN Inputs (Non-editable) -->
                            <div class="verified-section border rounded p-3 bg-light shadow-sm">
                                <div class="form-group mb-3">
                                    <label class="form-label fw-bold">PAN Number</label>
                                    <input type="text" class="form-control custom_readonly"
                                        value="<?php echo htmlspecialchars($vendordetail['pan_no'] ?? ''); ?>" readonly
                                        tabindex="-1">
                                </div>

                                <div class="form-group mb-3">
                                    <label class="form-label fw-bold">Company Name</label>
                                    <input type="text" id="company_name" class="form-control custom_readonly"
                                        value="<?php echo htmlspecialchars($vendordetail['company'] ?? ''); ?>" readonly
                                        tabindex="-1">
                                </div>

                                <small class="text-muted d-block mt-2">
                                    <i class="fa fa-lock"></i> This verification is completed and cannot be edited.
                                    Contact the administrator if changes are needed.
                                </small>
                            </div>
                        <?php else: ?> 
                            <!-- PAN Input Form (Editable) -->
                            <div class="form-group <?php echo $vendordetail['email']!=""?"event_disabled":""; ?>">
                                <label class="form-label">Email <span class="text-danger">*</span></label>
                                <input type="email" class="form-control company-email-input" id="company_email" placeholder="Enter company email" value="<?php echo $vendordetail['email'] ?? ''; ?>" >
                            </div>

                            <div class="form-group <?php echo $vendordetail['company']!=""?"event_disabled":""; ?>">
                                <label class="form-label">Company Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control company-name-input"
                                    id="company_name" placeholder="Enter company name"
                                    value="<?php echo $vendordetail['company'] ?? ''; ?>" >
                                <input type="hidden" id="company_check_status" value="">
                                <span class="text-danger f-12" id="allreadycompanyname" style="display:none">
                                    Company Name Already Register
                                </span>
                            </div>

                            <div class="form-group">
                                <label class="form-label">PAN Number <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <input type="text" class="form-control pan-input" id="pan_number" placeholder="ABCDE1234F"
                                        maxlength="10" style="text-transform: uppercase;"
                                        value="<?php echo $vendordetail['pan_no'] ?? ''; ?>">
                                    <span class="input-group-text status-icon">
                                        <i class="fa fa-clock-o text-muted"></i>
                                    </span>
                                </div>
                                <small class="text-muted">Format: ABCDE1234F (5 letters, 4 digits, 1 letter)</small>
                            </div>

                            <div class="form-group">
                                <div class="row mt-2">
                                    <div class="col-lg-12">
                                        <button type="button" class="btn btn-secondary btn-sm toggle-edit-btn" id="pan_edit_btn"
                                            data-section="pan">
                                            Change Info
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Hidden verify button for internal use -->
                            <button type="button" class="btn btn-primary verify-btn" id="verify_pan_btn" data-verification-type="pan"
                                style="display: none;">
                                <i class="fa fa-search"></i> Verify PAN
                            </button>
                        <?php endif; ?>

                    </div>

                    <div class="col-md-6">
                        <div id="pan_verification_fields" class="verification-fields">
                            <h5><i class="fa fa-info-circle"></i> PAN Verification Details</h5>
                            <div class="row">
                                <div class="col-12 form-group">
                                    <label class="form-label">Verified Name</label>
                                    <input type="text" class="form-control custom_readonly" id="pan_verified_name" readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">PAN Type</label>
                                    <input type="text" class="form-control custom_readonly" id="pan_verified_type" readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Status</label>
                                    <input type="text" class="form-control custom_readonly" id="pan_verified_status" readonly>
                                </div>
                            </div>
                        </div>

                        <div id="pan_confirmation_section" class="confirmation-section">
                            <h6><i class="fa fa-check-circle text-success"></i> PAN Verification Completed</h6>
                            <p class="mb-0">PAN details have been successfully verified and match your records.</p>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $step_counter++;
        } elseif ($verification_type == 'GSTIN') {
            ?>
            <!-- Step <?php echo $step_counter; ?>: GST Verification -->
            <div id="step-<?php echo $step_counter; ?>" class="verification-step">
                <div class="step-header">
                    <?php if ($is_verified): ?>
                        <h3><i class="fa fa-check-circle text-success"></i> GST Number Verification - Completed</h3>
                        <p class="text-success">Your GST has been successfully verified on
                            <?php echo date('d M Y, h:i A', strtotime($vendor_verifications['GSTIN']['verification_datetime'])); ?>
                        </p>
                    <?php else: ?>
                        <h3><i class="fa fa-building text-primary"></i> GST Number Verification <?php echo in_array('GSTIN', $required_document_verifications) ? '<span class="text-danger">*</span>' : ''; ?></h3>
                        <p>Verify your GST registration details and business information</p>
                    <?php endif; ?>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <?php if ($is_verified): ?>
                            <!-- Verified GST Inputs (Non-editable) -->
                            <div class="verified-section border rounded p-3 bg-light shadow-sm">
                                <div class="form-group mb-3">
                                    <label class="form-label fw-bold">GST Number</label>
                                    <input type="text" class="form-control custom_readonly"
                                        value="<?php echo htmlspecialchars($vendordetail['gstin'] ?? ''); ?>" readonly
                                        tabindex="-1">
                                </div>

                                <div class="form-group mb-3">
                                    <label class="form-label fw-bold">Verification Date</label>
                                    <input type="text" class="form-control custom_readonly" value="<?php echo !empty($vendor_verifications['GSTIN']['verification_datetime'])
                                        ? date('d M Y, h:i A', strtotime($vendor_verifications['GSTIN']['verification_datetime']))
                                        : ''; ?>" readonly tabindex="-1">
                                </div>

                                <small class="text-muted d-block mt-2">
                                    <i class="fa fa-lock"></i> This verification is completed and cannot be edited.
                                    Contact the administrator if changes are needed.
                                </small>
                            </div>

                        <?php else: ?>
                            <!-- GST Input Form (Editable) -->
                            <div class="form-group">
                                <label class="form-label">GST Number <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <input type="text" class="form-control gst-input" id="gstin" placeholder="22AAAAA0000A1Z5"
                                        maxlength="15" style="text-transform: uppercase;"
                                        value="<?php echo $vendordetail['gstin'] ?? ''; ?>">
                                    <span class="input-group-text status-icon">
                                        <i class="fa fa-clock-o text-muted"></i>
                                    </span>
                                </div>
                                <small class="text-muted">
                                    Format: 15 characters (2 digits + 10 PAN + 1 digit + 1 letter + 1 digit/letter)
                                </small>
                            </div>

                            <div class="form-group">
                                <div class="row mt-2">
                                    <div
                                        class="col-lg-<?php echo in_array('GSTIN', $required_document_verifications) ? '12' : '6'; ?>">
                                        <button type="button" class="btn btn-secondary btn-sm toggle-edit-btn" id="gstin_edit_btn"
                                            data-section="gstin">
                                            Change Info
                                        </button>
                                    </div>
                                    <?php if (!in_array('GSTIN', $required_document_verifications)): ?>
                                        <div class="col-lg-6">
                                            <button type="button" class="btn btn-info btn-sm skip-step-btn" data-step-type="gstin">
                                                Skip This Step
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php if (!in_array('GSTIN', $required_document_verifications)): ?>
                                    <div class="row mt-2">
                                        <div class="col-lg-12">
                                            <small class="text-muted">
                                                If you don't have GST registration, you can skip this step and continue with the
                                                verification process.
                                            </small>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Hidden verify button for internal use -->
                            <button type="button" class="btn btn-primary verify-btn" id="verify_gst_btn" data-verification-type="gst"
                                style="display: none;">
                                <i class="fa fa-search"></i> Verify GST
                            </button>

                            <!-- GST Address Options -->
                            <div id="gst_address_options" style="display: none;" class="mt-3">
                                <!-- Address options will be populated by JavaScript -->
                            </div>
                        <?php endif; ?>

                    </div>

                    <div class="col-md-6">
                        <div id="gst_verification_fields" class="verification-fields">
                            <h5><i class="fa fa-info-circle"></i> GST Verification Details</h5>
                            <div class="row">
                                <div class="col-6 form-group">
                                    <label class="form-label">Legal Name</label>
                                    <input type="text" class="form-control custom_readonly" id="gstin_legal_name" readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Trade Name</label>
                                    <input type="text" class="form-control custom_readonly" id="gstin_trade_name" readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Registration Status</label>
                                    <input type="text" class="form-control custom_readonly" id="gstin_registration_status"
                                        readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Taxpayer Type</label>
                                    <input type="text" class="form-control custom_readonly" id="gstin_taxpayer_type" readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Business Nature</label>
                                    <input type="text" class="form-control custom_readonly" id="gstin_business_nature" readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Registration Date</label>
                                    <input type="text" class="form-control custom_readonly" id="gstin_registration_date"
                                        readonly>
                                </div>
                                <div class="col-12 form-group">
                                    <label class="form-label">Business Address</label>
                                    <textarea class="form-control custom_readonly" id="gstin_business_address" rows="2"
                                        readonly></textarea>
                                </div>
                            </div>
                        </div>

                        <div id="gst_confirmation_section" class="confirmation-section">
                            <h6><i class="fa fa-check-circle text-success"></i> GST Verification Completed</h6>
                            <p class="mb-0">GST details have been successfully verified and business information retrieved.</p>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $step_counter++;
        } elseif ($verification_type == 'BANK') {
            ?>
            <!-- Step <?php echo $step_counter; ?>: Bank Verification -->
            <div id="step-<?php echo $step_counter; ?>" class="verification-step">
                <div class="step-header">
                    <?php if ($is_verified): ?>
                        <h3><i class="fa fa-check-circle text-success"></i> Bank Account Verification - Completed</h3>
                        <p class="text-success">Your Bank Account has been successfully verified on
                            <?php echo date('d M Y, h:i A', strtotime($vendor_verifications['BANK']['verification_datetime'])); ?>
                        </p>
                    <?php else: ?>
                        <h3><i class="fa fa-university text-primary"></i> Bank Account Verification <?php echo in_array('BANK', $required_document_verifications) ? '<span class="text-danger">*</span>' : ''; ?></h3>
                        <p>Verify your bank account details for secure transactions</p>
                    <?php endif; ?>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <?php if ($is_verified): ?>
                            <!-- Verified Bank Inputs (Non-editable) -->
                            <div class="verified-section border rounded p-3 bg-light shadow-sm">
                                <div class="form-group mb-3">
                                    <label class="form-label fw-bold">IFSC Code</label>
                                    <input type="text" class="form-control custom_readonly"
                                        value="<?php echo htmlspecialchars($vendordetail['ifsc_code'] ?? ''); ?>" readonly
                                        tabindex="-1">
                                </div>

                                <div class="form-group mb-3">
                                    <label class="form-label fw-bold">Bank Account Number</label>
                                    <input type="text" class="form-control custom_readonly"
                                        value="<?php echo htmlspecialchars($vendordetail['bank_account_no'] ?? ''); ?>" readonly
                                        tabindex="-1">
                                </div>

                                <div class="form-group mb-3">
                                    <label class="form-label fw-bold">Verification Date</label>
                                    <input type="text" class="form-control custom_readonly" value="<?php echo !empty($vendor_verifications['BANK']['verification_datetime'])
                                        ? date('d M Y, h:i A', strtotime($vendor_verifications['BANK']['verification_datetime']))
                                        : ''; ?>" readonly tabindex="-1">
                                </div>

                                <small class="text-muted d-block mt-2">
                                    <i class="fa fa-lock"></i> This verification is completed and cannot be edited.
                                    Contact the administrator if changes are needed.
                                </small>
                            </div>

                        <?php else: ?>
                            <!-- Bank Input Form (Editable) -->
                            <div class="form-group mb-3">
                                <label class="form-label">IFSC Code <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <input type="text" class="form-control ifsc-input" id="ifsc_code" placeholder="SBIN0001234"
                                        maxlength="11" style="text-transform: uppercase;"
                                        value="<?php echo htmlspecialchars($vendordetail['ifsc_code'] ?? ''); ?>">
                                    <span class="input-group-text status-icon">
                                        <i class="fa fa-clock-o text-muted"></i>
                                    </span>
                                </div>
                                <small class="text-muted">Format: ABCD0123456 (4 letters + 0 + 6 digits/letters)</small>
                            </div>

                            <div class="form-group mb-3">
                                <label class="form-label">Bank Account Number <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <input type="text" class="form-control bank-account-input" id="bank_account_no" placeholder="Enter account number"
                                        value="<?php echo htmlspecialchars($vendordetail['bank_account_no'] ?? ''); ?>">
                                    <span class="input-group-text status-icon">
                                        <i class="fa fa-clock-o text-muted"></i>
                                    </span>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row mt-2">
                                    <div
                                        class="col-lg-<?php echo in_array('BANK', $required_document_verifications) ? '12' : '6'; ?>">
                                        <button type="button" class="btn btn-secondary btn-sm toggle-edit-btn" id="bank_edit_btn"
                                            data-section="bank">
                                            Change Info
                                        </button>
                                    </div>
                                    <?php if (!in_array('BANK', $required_document_verifications)): ?>
                                        <div class="col-lg-6">
                                            <button type="button" class="btn btn-info btn-sm skip-step-btn" data-step-type="bank">
                                                Skip This Step
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php if (!in_array('BANK', $required_document_verifications)): ?>
                                    <div class="row mt-2">
                                        <div class="col-lg-12">
                                            <small class="text-muted">
                                                If you don't have bank account details ready, you can skip this step and continue with
                                                the verification process.
                                            </small>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Hidden verify button for internal use -->
                            <button type="button" class="btn btn-primary verify-btn" id="verify_bank_btn" data-verification-type="bank"
                                style="display: none;">
                                <i class="fa fa-search"></i> Verify Bank Account
                            </button>
                        <?php endif; ?>

                    </div>

                    <div class="col-md-6">
                        <div id="bank_verification_fields" class="verification-fields">
                            <h5><i class="fa fa-info-circle"></i> Bank Verification Details</h5>
                            <div class="row">
                                <div class="col-6 form-group">
                                    <label class="form-label">IFSC Code</label>
                                    <input type="text" class="form-control custom_readonly" id="bank_verified_ifsc" readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Account Number</label>
                                    <input type="text" class="form-control custom_readonly" id="bank_verified_account" readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Beneficiary Name</label>
                                    <input type="text" class="form-control custom_readonly" id="bank_verified_name" readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Verification Status</label>
                                    <input type="text" class="form-control custom_readonly" id="bank_verified_status" readonly>
                                </div>
                            </div>
                        </div>

                        <div id="bank_confirmation_section" class="confirmation-section">
                            <h6><i class="fa fa-check-circle text-success"></i> Bank Verification Completed</h6>
                            <p class="mb-0">Bank account details have been successfully verified.</p>
                        </div>

                        <!-- Manual Confirmation Section -->
                        <div id="bank_manual_confirmation_section" class="confirmation-section" style="display: none; background: #fff3cd; border-left: 4px solid #ffc107;">
                            <h6><i class="fa fa-exclamation-triangle text-warning"></i> Please Confirm Bank Account Details</h6>
                            <p class="mb-3">The bank account has been successfully verified. Please review the details below and confirm if they are correct:</p>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <strong>IFSC Code:</strong> <span id="confirm_ifsc_display"></span>
                                </div>
                                <div class="col-md-6">
                                    <strong>Account Number:</strong> <span id="confirm_account_display"></span>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-12">
                                    <strong>Account Holder Name:</strong> <span id="confirm_name_display"></span>
                                </div>
                            </div>
                            
                            <div class="text-center">
                                <button type="button" class="btn btn-success mr-2 confirm-bank-btn">
                                    <i class="fa fa-check"></i> Yes, These Details Are Correct
                                </button>
                                <button type="button" class="btn btn-secondary cancel-bank-btn">
                                    <i class="fa fa-times"></i> Cancel
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $step_counter++;
        } elseif ($verification_type == 'MSME') {
            ?>
            <!-- Step <?php echo $step_counter; ?>: MSME Verification -->
            <div id="step-<?php echo $step_counter; ?>" class="verification-step">
                <div class="step-header">
                    <?php if ($is_verified): ?>
                        <h3><i class="fa fa-check-circle text-success"></i> MSME/Udyam Registration Verification - Completed</h3>
                        <p class="text-success">Your MSME has been successfully verified on
                            <?php echo date('d M Y, h:i A', strtotime($vendor_verifications['MSME']['verification_datetime'])); ?>
                        </p>
                    <?php else: ?>
                        <h3><i class="fa fa-check text-primary"></i> MSME/Udyam Registration Verification <?php echo in_array('MSME', $required_document_verifications) ? '<span class="text-danger">*</span>' : ''; ?></h3>
                        <p>Verify your MSME/Udyam registration details</p>
                    <?php endif; ?>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <?php if ($is_verified): ?>
                            <!-- Verified MSME Inputs (Non-editable) -->
                            <div class="verified-section border rounded p-3 bg-light shadow-sm">
                                <div class="form-group mb-3">
                                    <label class="form-label fw-bold">MSME/Udyam Registration Number</label>
                                    <input type="text" class="form-control custom_readonly"
                                        value="<?php echo htmlspecialchars($vendordetail['msme_number'] ?? ''); ?>" readonly
                                        tabindex="-1">
                                </div>

                                <div class="form-group mb-3">
                                    <label class="form-label fw-bold">Verification Date</label>
                                    <input type="text" class="form-control custom_readonly" value="<?php echo !empty($vendor_verifications['MSME']['verification_datetime'])
                                        ? date('d M Y, h:i A', strtotime($vendor_verifications['MSME']['verification_datetime']))
                                        : ''; ?>" readonly tabindex="-1">
                                </div>

                                <small class="text-muted d-block mt-2">
                                    <i class="fa fa-lock"></i> This verification is completed and cannot be edited.
                                    Contact the administrator if changes are needed.
                                </small>
                            </div>

                        <?php else: ?>
                            <!-- MSME Input Form (Editable) -->
                            <div class="form-group">
                                <label class="form-label">MSME/Udyam Registration Number</label>
                                <div class="input-group">
                                    <input type="text" class="form-control msme-input" id="msme_number" placeholder="UDYAM-XX-00-0000000"
                                        maxlength="19" style="text-transform: uppercase;"
                                        value="<?php echo $vendordetail['msme_number'] ?? ''; ?>">
                                    <span class="input-group-text status-icon">
                                        <i class="fa fa-clock-o text-muted"></i>
                                    </span>
                                </div>
                                <small class="text-muted">Format: UDYAM-XX-00-0000000</small>
                            </div>

                            <div class="form-group">
                                <div class="row mt-2">
                                    <div
                                        class="col-lg-<?php echo in_array('MSME', $required_document_verifications) ? '12' : '6'; ?>">
                                        <button type="button" class="btn btn-secondary btn-sm toggle-edit-btn" id="msme_edit_btn"
                                            data-section="msme">
                                            Change Info
                                        </button>
                                    </div>
                                    <?php if (!in_array('MSME', $required_document_verifications)): ?>
                                        <div class="col-lg-6">
                                            <button type="button" class="btn btn-info btn-sm skip-step-btn" data-step-type="msme">
                                                Skip This Step
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php if (!in_array('MSME', $required_document_verifications)): ?>
                                    <div class="row mt-2">
                                        <div class="col-lg-12">
                                            <small class="text-muted">
                                                If you don't have MSME/Udyam registration, you can skip this step and continue with the
                                                verification process.
                                            </small>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Hidden verify button for internal use -->
                            <button type="button" class="btn btn-primary verify-btn" id="verify_msme_btn" data-verification-type="msme"
                                style="display: none;">
                                <i class="fa fa-search"></i> Verify MSME
                            </button>
                        <?php endif; ?>

                    </div>

                    <div class="col-md-6">
                        <div id="msme_verification_fields" class="verification-fields">
                            <h5><i class="fa fa-info-circle"></i> MSME Verification Details</h5>
                            <div class="row">
                                <div class="col-6 form-group">
                                    <label class="form-label">Enterprise Name</label>
                                    <input type="text" class="form-control custom_readonly" id="msme_verified_enterprise_name"
                                        readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Major Activity</label>
                                    <input type="text" class="form-control custom_readonly" id="msme_verified_major_activity"
                                        readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Organization Type</label>
                                    <input type="text" class="form-control custom_readonly" id="msme_verified_organization_type"
                                        readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Social Category</label>
                                    <input type="text" class="form-control custom_readonly" id="msme_verified_social_category"
                                        readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Commencement Date</label>
                                    <input type="text" class="form-control custom_readonly" id="msme_verified_commencement_date"
                                        readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">DIC Name</label>
                                    <input type="text" class="form-control custom_readonly" id="msme_verified_dic_name"
                                        readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Registration Date</label>
                                    <input type="text" class="form-control custom_readonly" id="msme_verified_registration_date"
                                        readonly>
                                </div>
                                <div class="col-6 form-group">
                                    <label class="form-label">Status</label>
                                    <input type="text" class="form-control custom_readonly" id="msme_verified_status" readonly>
                                </div>
                            </div>
                        </div>

                        <div id="msme_confirmation_section" class="confirmation-section">
                            <h6><i class="fa fa-check-circle text-success"></i> MSME Verification Completed</h6>
                            <p class="mb-0">MSME registration details have been successfully verified.</p>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $step_counter++;
        } elseif ($verification_type == 'TAN') {
            ?>
            <!-- Step <?php echo $step_counter; ?>: TAN Verification -->
            <div id="step-<?php echo $step_counter; ?>" class="verification-step">
                <div class="step-header">
                    <?php if ($is_verified): ?>
                        <h3><i class="fa fa-check-circle text-success"></i> TAN Number Verification - Completed</h3>
                        <p class="text-success">Your TAN has been successfully verified on
                            <?php echo date('d M Y, h:i A', strtotime($vendor_verifications['TAN']['verification_datetime'])); ?>
                        </p>
                    <?php else: ?>
                        <h3><i class="fa fa-file-text text-primary"></i> TAN Number Verification <?php echo in_array('TAN', $required_document_verifications) ? '<span class="text-danger">*</span>' : ''; ?></h3>
                        <p>Verify your Tax Deduction Account Number</p>
                    <?php endif; ?>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <?php if ($is_verified): ?>
                            <!-- Verified TAN Inputs (Non-editable) -->
                            <div class="verified-section border rounded p-3 bg-light shadow-sm">
                                <div class="form-group mb-3">
                                    <label class="form-label fw-bold">TAN Number</label>
                                    <input type="text" class="form-control custom_readonly"
                                        value="<?php echo htmlspecialchars($vendordetail['tan_number'] ?? ''); ?>" readonly
                                        tabindex="-1">
                                </div>

                                <div class="form-group mb-3">
                                    <label class="form-label fw-bold">Verification Date</label>
                                    <input type="text" class="form-control custom_readonly" value="<?php echo !empty($vendor_verifications['TAN']['verification_datetime'])
                                        ? date('d M Y, h:i A', strtotime($vendor_verifications['TAN']['verification_datetime']))
                                        : ''; ?>" readonly tabindex="-1">
                                </div>

                                <small class="text-muted d-block mt-2">
                                    <i class="fa fa-lock"></i> This verification is completed and cannot be edited.
                                    Contact the administrator if changes are needed.
                                </small>
                            </div>

                        <?php else: ?>
                            <!-- TAN Input Form (Editable) -->
                            <div class="form-group">
                                <label class="form-label">TAN Number</label>
                                <div class="input-group">
                                    <input type="text" class="form-control tan-input" id="tan_number" placeholder="ABCD12345E"
                                        maxlength="10" style="text-transform: uppercase;"
                                        value="<?php echo $vendordetail['tan_number'] ?? ''; ?>">
                                    <span class="input-group-text status-icon">
                                        <i class="fa fa-clock-o text-muted"></i>
                                    </span>
                                </div>
                                <small class="text-muted">Format: ABCD12345E (4 letters + 5 digits + 1 letter)</small>
                            </div>

                            <div class="form-group">
                                <div class="row mt-2">
                                    <div
                                        class="col-lg-<?php echo in_array('TAN', $required_document_verifications) ? '12' : '6'; ?>">
                                        <button type="button" class="btn btn-secondary btn-sm toggle-edit-btn" id="tan_edit_btn"
                                            data-section="tan">
                                            Change Info
                                        </button>
                                    </div>
                                    <?php if (!in_array('TAN', $required_document_verifications)): ?>
                                        <div class="col-lg-6">
                                            <button type="button" class="btn btn-info btn-sm skip-step-btn" data-step-type="tan">
                                                Skip This Step
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php if (!in_array('TAN', $required_document_verifications)): ?>
                                    <div class="row mt-2">
                                        <div class="col-lg-12">
                                            <small class="text-muted">
                                                If you don't have a TAN number, you can skip this step and continue with the
                                                verification process.
                                            </small>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- Hidden verify button for internal use -->
                            <button type="button" class="btn btn-primary verify-btn" id="verify_tan_btn" data-verification-type="tan"
                                style="display: none;">
                                <i class="fa fa-search"></i> Verify TAN
                            </button>
                        <?php endif; ?>

                    </div>

                    <div class="col-md-6">
                        <div id="tan_verification_fields" class="verification-fields">
                            <h5><i class="fa fa-info-circle"></i> TAN Verification Details</h5>
                            <div class="row">
                                <div class="col-12 form-group">
                                    <label class="form-label">Company Name</label>
                                    <input type="text" class="form-control custom_readonly" id="tan_verified_company" readonly>

                                </div>
                                <div class="col-12 form-group">
                                    <label class="form-label">Verification Status</label>
                                    <input type="text" class="form-control custom_readonly" id="tan_verified_status" readonly>
                                </div>
                            </div>
                        </div>

                        <div id="tan_confirmation_section" class="confirmation-section">
                            <h6><i class="fa fa-check-circle text-success"></i> TAN Verification Completed</h6>
                            <p class="mb-0">TAN details have been successfully verified.</p>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            $step_counter++;
        }
    }
    ?>

    <!-- Navigation Buttons -->
    <div class="navigation-buttons">
        <button type="button" class="btn btn-secondary prev-step-btn" id="prevBtn" style="display: none;">
            <i class="fa fa-arrow-left"></i> Previous
        </button>

        <div>
            <button type="button" class="btn btn-primary next-step-btn" id="nextBtn">
                Next <i class="fa fa-arrow-right"></i>
            </button>
            <button type="button" class="btn btn-success complete-verification-btn" id="completeBtn"
                style="display: none;">
                <i class="fa fa-check"></i> Complete Verification
            </button>
        </div>
    </div>
</div>

<script src="./assets/js/custom_insert_vendor_and_vendor_registers_verifications.js"></script>