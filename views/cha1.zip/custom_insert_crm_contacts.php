<?php 
include('../includes/session.php');
include('../dbconfig.php');
include('../comm.php');
$rid = $_POST['rid'];
$transaction_table = "crm_contacts";
$apiusrl = CRMAPI."?mode=getcrmleads&transaction_table=".$transaction_table."&rid=".$rid; 
$page_list = callAPI($apiusrl);
$res = json_decode($page_list,1);
//echo "crm_source_typescrm_source_typescrm_source_typescrm_source_typescrm_source_types<pre>"; print_r($res['crm_source_types']); echo "</pre>";
$transaction = $res['transaction'];
$crm_source_types = $res['crm_source_types'];
$application_users = $res['application_users'];
$countries =$res['countries']; 
$states =$res['states']; 
$cities =$res['cities']; 
$crm_companies =$res['crm_companies'];
// //$application_users = $res['application_users'];
// //$leadsourceary = array("1"=>"Self","2"=>"Facebok","3"=>"Instagram","4"=>"Linkdin");
// $responsible = $crm_leads['responsible_id'] !=""?$crm_leads['responsible_id']:$_SESSION['userid'];
// $countries =$res['countries']; 
// $states =$res['states']; 
// $cities =$res['cities']; 
// $crm_lead_types =$res['crm_lead_types']; 
// $crmleaddetailstypes = array();
// foreach($crm_lead_types as $crmlt){
//     if($crmlt['type'] == 2){
//         $crmleaddetailstypes[$crmlt['id']] =$crmlt;
//     } 
// }
// $crm_lead_details = $res['crm_lead_details'];
// $email_content = $res['email_content'];
//print_r($email_content);?>
<script type="text/javascript">
    function pageCallHistories(rid){
        var loader = '<div class="text-center" id="loader-show"><img src="assets/images/spiner/spiner3.gif" style="width: 300px;"></div>';
        $("#crmleadhistories").html(loader);
        jQuery.ajax({
            url: "views/custom_insert_crm_lead_histories.php",
            data: "rrid="+rid,
            type: "POST",
            success:function(data){
                $("#crmleadhistories").html(data);
                //$(window).scrollTop($('#crmleadhistories').offset().top);

            }
        });
    }
    function submitLeadForm(){
        var validations = ajaxFormSubmitValidation();
        if(validations == 0){
            var crm_lead_id = $("#crm_lead_id").val();
            var formvalue =  $("#submit_lead_form").serialize();
            jQuery.ajax({
                url: "ajax.php",
                data: "page=insertcrmleads&"+formvalue,
                type: "POST",
                success:function(data){
                    console.log(data);
                    var jsonres = JSON.parse(data);
                    console.log(jsonres.res.status);
                    if(jsonres.res.status == "sucess"){
                        tostarnotify('top','right','fa fa-thumbs-up','form-label label label-success','animated flipInX','animated flipOutX','<?php echo $_SESSION['error_message']['3000']; ?>','');
                            closeOpenBox();
                            $('#htmlsetpage').html('');
                            location.reload();
                    }else{
                        tostarnotify('top','right','fa fa-thumbs-down','form-label label label-danger','animated flipInX','animated flipOutX',jsonres.res.message,'');
                    }
                }
            });
        }
    }
    function submitLeadFormDetail(formid){
        var crm_lead_id = $("#crm_lead_id").val();
        var formvalue =  $("#"+formid).serialize();
        jQuery.ajax({
            url: "ajax.php",
            data: "page=insertcrmleaddetails&crm_lead_id="+crm_lead_id+"&"+formvalue,
            type: "POST",
            success:function(data){
                console.log(data);
                var jsonres = JSON.parse(data);
                console.log(jsonres.res.status);
                if(jsonres.res.status == "sucess"){
                    tostarnotify('top','right','fa fa-thumbs-up','form-label label label-success','animated flipInX','animated flipOutX','<?php echo $_SESSION['error_message']['3000']; ?>','');
                    pageCallHistories(crm_lead_id);
                        //closeOpenBox();
                        //$('#htmlsetpage').html('');
                       // location.reload();
                }else{
                    tostarnotify('top','right','fa fa-thumbs-down','form-label label label-danger','animated flipInX','animated flipOutX',jsonres.res.message,'');
                }
            }
        });
    }
    function closeOpenBox(){
        var my_val = $('.pcoded').attr('vertical-placement');
        if (my_val == 'right') {
            var options = {
                direction: 'left'
            };
        } else {
            var options = {
                direction: 'right'
            };
        }
        $('.leadsidebar-form').toggle('slide', options, 500);
        $('.leadsidebar-form').css('display', 'block');
    }

    function selectedcategory(selected_id,element_id,table_name,field_name) {
      var selectedvalues = selected_id;
      // if(table_name=='states'){
      //   document.getElementById('selectedcountry').value= selectedvalues[1];
      // }
      // if(table_name=='cities'){
      //   document.getElementById('selectedstate').value= selectedvalues[1];
      // }
      // if(table_name=='city'){
      //   document.getElementById('selectedcity').value= selectedvalues[1];
      // }
     if(table_name=='states' || table_name=='cities'){
       $.ajax({
        url: "ajax.php",
        data:'page=getselectedlist&table_name='+table_name+'&id='+selectedvalues+'&field='+field_name,
        type: "POST",
        success: function(response) {
          console.log(response);
          var response = JSON.parse(response);
          console.log(response.length);
          var select = document.getElementById(element_id); 
          document.getElementById(element_id).innerHTML = null;
          for (var i = 0; i < response.length; i++) 
          {
           var el = document.createElement("option");
           if(table_name=='states'){
            el.textContent = response[i].state_name;
            el.value = response[i].id;
          }
          if(table_name=='cities'){
            el.textContent = response[i].city_name;
            el.value = response[i].id;
          }
          select.add(el);

          console.log(el);
        }
      }
    });
     }

   }

</script>
<div class="user-box">
    <div class="chat-search-box border-bottom">
        <a class="back_leadsidebar-form">
            <i class="ti-close icon-x"></i>
        </a>
        <div class="right-icon-control">
            <h4 class="text-dark f-20 f-w-600 text-left">Add Contact</h4>
        </div>
    </div>
    <div class="main-friend-list card-body form-design custom-scroll" style="height: 600px">
        <div class="row">
            <div class="col-lg-5">
                <form id="submit_lead_form">
                <input type="hidden" name="rid" id="rid" value="<?php echo $rid; ?>">
                 <input type="hidden" name="transaction_table" id="transaction_table" value="<?php echo $transaction_table; ?>">
                <div class="bg-white p-3 b-radius-10">
                    <h5 class="f-18 f-w-600 bg-gray p-2">Additional Information</h5>
                    <div class="row mt-3">
                        <div class="col-lg-6 form-group w-full">
                            <label class="form-label">Contact Source <span class="requried">*</span></label>
                            <span class="d-block error-message text-danger"></span>
                            <select class="form-control js-example-basic-single requried_field" name="contact_source">
                                <?php foreach($crm_source_types as $lsval){ ?>
                                    <option value="<?php echo $lsval['id']; ?>" <?php echo $transaction['contact_source'] == $lsval['id']?"selected":"";?>><?php echo $lsval['source_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-lg-6 form-group w-full">
                            <label class="form-label">Originator <span class="requried">*</span></label>
                             <span class="d-block error-message text-danger"></span>
                            <select class="form-control js-example-basic-single requried_field" name="originator">
                                <option value="">Select Any One</option>
                               <?php foreach($application_users as $uval){ ?>
                                    <option value="<?php echo $uval['id']; ?>" <?php echo ($transaction['originator'] == $uval['id'] OR ($transaction['originator'] == "" AND $_SESSION['userid']== $uval['id']))?"selected":"";?>><?php echo $uval['display_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-lg-6  form-group">
                            <label class="form-label">Company </label>
                            <select class="form-control js-example-basic-single" name="crm_company_id">
                                <option value="">Select Any One</option>
                               <?php foreach($crm_companies as $uval){ ?>
                                    <option value="<?php echo $uval['id']; ?>" <?php echo ($transaction['crm_company_id'] == $uval['id'] OR ($transaction['crm_company_id'] == "" AND $_SESSION['userid']== $uval['id']))?"selected":"";?>><?php echo $uval['display_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-lg-6  form-group">
                            <label class="form-label">Phone No. <span class="requried">*</span></label>
                            <span class="d-block error-message text-danger"></span>
                            <input class="form-control requried_field" type="tel" name="phone" placeholder="Phone" value="<?php echo $transaction['phone']; ?>">
                        </div>
                        <div class="col-lg-4 form-group">
                            <label class="form-label">First Name <span class="requried">*</span></label>
                             <span class="d-block error-message text-danger"></span>
                            <input class="form-control requried_field" type="text" name="first_name" placeholder="First Name" value="<?php echo $transaction['first_name']; ?>">
                        </div>
                        <div class="col-lg-4 form-group">
                            <label class="form-label">Middle Name</label>
                            <input class="form-control" type="text" name="middle_name" placeholder="Middle Name" value="<?php echo $transaction['middle_name']; ?>">
                        </div>
                        <div class="col-lg-4 form-group">
                            <label class="form-label">last Name <span class="requried">*</span></label>
                            <span class="d-block error-message text-danger"></span>
                            <input class="form-control requried_field" type="text" name="last_name" placeholder="Last Name" value="<?php echo $transaction['last_name']; ?>">
                        </div>
                        <div class="col-lg-6 form-group">
                            <label class="form-label">Email </label>
                            <input class="form-control" type="email" name="email_id" placeholder="Email" value="<?php echo $transaction['email_id']; ?>">
                        </div>
                        
                        <div class="col-lg-6  form-group">
                            <label class="form-label">Office No.</label>
                            <input class="form-control" type="tel" name="office_phone" placeholder="Phone" value="<?php echo $transaction['office_phone']; ?>">
                        </div>
                        <div class="col-lg-6 form-group">
                            <label class="form-label">Fax</label>
                            <input class="form-control" type="text" name="fax" placeholder="Fax" value="<?php echo $transaction['fax']; ?>">
                        </div>
                        <div class="col-lg-6  form-group">
                            <label class="form-label">Website</label>
                            <input class="form-control" type="text" name="website" placeholder="Website" value="<?php echo $transaction['website']; ?>">
                        </div>
                    </div>
                    <h5 class="f-18 f-w-600 bg-gray p-2">Address Information</h5>
                    <div class="row mt-3">
                        <div class="col-lg-12 form-group">
                            <label class="form-label">Mailing Address</label>
                            <div class="grow-wrap">
                                <textarea  placeholder="Address" class="border form-control" rows="3" name="address" oninput="this.parentNode.dataset.replicatedValue = this.value"><?php echo $transaction['address']; ?></textarea>
                            </div>
                        </div>
                        <div class="col-lg-6 form-group w-full">
                            <label class="form-label">Country</label>
                            <select class="form-control js-example-basic-single" name="country_id" onchange="selectedcategory(this.value,'state_id','states','country_id')">
                                <option value="">Select Any One</option>
                                <?php foreach($countries as $cval){ ?>
                                    <option value="<?php echo $cval['id']; ?>" <?php echo $transaction['country_id'] == $cval['id']?"selected":"";?>><?php echo $cval['country_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-lg-6 form-group w-full">
                            <label class="form-label">State</label>
                            <select class="form-control js-example-basic-single" name="state_id" id="state_id" onchange="selectedcategory(this.value,'city_id','cities','state_id')">
                                <option value="">Select Any One</option>
                                <?php foreach($states as $cval){ ?>
                                    <option value="<?php echo $cval['id']; ?>" <?php echo $transaction['state_id'] == $cval['id']?"selected":"";?>><?php echo $cval['state_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-lg-6 form-group w-full">
                            <label class="form-label">City</label>
                            <select class="form-control js-example-basic-single" name="city_id" id="city_id">
                                <option value="">Select Any One</option>
                                <?php foreach($cities as $cval){ ?>
                                    <option value="<?php echo $cval['id']; ?>" <?php echo $transaction['city_id'] == $cval['id']?"selected":"";?>><?php echo $cval['city_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-lg-6 form-group">
                            <label class="form-label">Post Code</label>
                            <input class="form-control" type="text" name="post_code" placeholder="Postal Code" value="<?php echo $transaction['post_code']; ?>">
                        </div>
                    </div>
                    <h5 class="f-18 f-w-600 bg-gray p-2">Description Information</h5>
                    <div class="row mt-3">
                        <div class="col-lg-12 form-group">
                            <label class="form-label">Description</label>
                            <div class="grow-wrap">
                                <textarea name="remark" placeholder="Description" class="border form-control" rows="3" oninput="this.parentNode.dataset.replicatedValue = this.value"><?php echo $transaction['remark']; ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="mt-2">
                        <button type="button" class="btn btn-primary waves-effect waves-light" onclick="submitLeadForm()">Submit</button>
                        <button type="reset" class="btn btn-default waves-effect " data-bs-dismiss="modal">Reset</button>
                    </div>
                </div>
                </form>
            </div>
            <div class="col-lg-7">
                <?php if($rid ==""){ ?>
                <!-- <div class="card-px text-center ">
                    <p class="text-muted f-16 fw-bold m-b-30"><i class="ti ti-alert text-warning"></i> No Histories</p>   
                    <div class="text-center px-4">
                        <img class="mw-100 mh-300px" alt="" src="assets/images/work.png" style="max-height: 300px!important;">
                    </div>   
                </div> -->
             <?php }else{  /**/  ?>    
                <div class="card">
                    <div class="card-body">
                <!-- Nav tabs -->
                <ul class="nav md-tabs infisuite_tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-bs-toggle="tab" href="#comment" role="tab">Comment</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#wait" role="tab">Wait</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#call" role="tab">Call</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#sms" role="tab">SMS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#email" role="tab">E-mail</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#task" role="tab">Task</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#meeting" role="tab">Meeting</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="tab" href="#visit" role="tab">Visit</a>
                    </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content tabs card-block mt-3">
                    <div class="tab-pane active" id="comment" role="tabpanel">
                        <form id="form_comment">
                        <input type="hidden" name="lead_type" value="1">    
                        <div class="form-group">
                            <label class="form-label">Comment</label>
                            <textarea class="form-control" rows="3" oninput="this.parentNode.dataset.replicatedValue = this.value" name="comment"></textarea>
                        </div>
                        <div class="mt-2">
                            <button type="button" class="btn btn-primary waves-effect waves-light" onclick="submitLeadFormDetail('form_comment')">Submit</button>
                        </div>
                        </form>
                    </div>
                    <div class="tab-pane" id="wait" role="tabpanel">
                        <form id="form_wait">
                        <input type="hidden" name="lead_type" value="2">
                        <div class="row">
                            <div class="col-lg-6 form-group">
                                <label class="form-label">Date</label>
                                <input class="form-control datepicker" type="text" name="date" value="">
                            </div>
                            <div class="col-lg-6 form-group">
                                <label class="form-label">Time</label>
                                <input class="form-control" type="time" name="time" value="">
                            </div>
                            <div class="col-lg-12 form-group">
                                <label class="form-label">Comment</label>
                                <textarea class="form-control" rows="3" oninput="this.parentNode.dataset.replicatedValue = this.value" name="comment"></textarea>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="button" class="btn btn-primary waves-effect waves-light" onclick="submitLeadFormDetail('form_wait')">Submit</button>
                        </div>
                        </form>
                    </div>
                    <div class="tab-pane" id="call" role="tabpanel">
                        <form id="form_call">
                        <input type="hidden" name="lead_type" value="3">
                        <div class="row">
                            <div class="col-lg-6 form-group">
                                <label class="form-label">Date</label>
                                <input class="form-control datepicker" type="text" name="date" value="">
                            </div>
                            <div class="col-lg-6 form-group">
                                <label class="form-label">Time</label>
                                <input class="form-control" type="time" name="time"  value="">
                            </div>
                            <div class="col-lg-12 form-group">
                                <label class="form-label">Comment</label>
                                <textarea class="form-control" rows="3" oninput="this.parentNode.dataset.replicatedValue = this.value" name="comment"></textarea>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="button" class="btn btn-primary waves-effect waves-light" onclick="submitLeadFormDetail('form_call')">Submit</button>
                        </div>
                        </form>
                    </div>
                    <div class="tab-pane" id="sms" role="tabpanel">
                        <form id="form_sms">
                        <input type="hidden" name="lead_type" value="4">
                        <div class="row">
                            <div class="col-lg-12 form-group">
                                <label class="form-label">Mobile No.</label>
                                <input class="form-control" type="text" name="phone" value="<?php echo $crm_leads['phone']; ?>">
                            </div>
                            <div class="col-lg-12 form-group">
                                <label class="form-label">SMS Text</label>
                                <textarea class="form-control" rows="3" oninput="this.parentNode.dataset.replicatedValue = this.value" name="sms_text"></textarea>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="button" class="btn btn-primary waves-effect waves-light" onclick="submitLeadFormDetail('form_sms')">Submit</button>
                        </div>
                        </form>
                    </div>
                    <div class="tab-pane" id="email" role="tabpanel">
                        <form id="form_email">
                        <input type="hidden" name="lead_type" value="5">
                        <div class="row">
                            <div class="col-lg-6 form-group w-full">
                                <label class="form-label">Email Template</label>
                                <select class="form-control js-example-basic-single" name="email_content_id" >
                                <?php foreach($email_content as $cval){ ?>
                                    <option value="<?php echo $cval['template_reference_id']; ?>"><?php echo $cval['template_name']; ?></option>
                                <?php } ?>
                            </select>
                            </div>
                            <div class="col-lg-6 form-group">
                                <label class="form-label">Recipient Email</label>
                                <input class="form-control" type="text" name="recipient_email_id" value="<?php echo $crm_leads['email_id']; ?>">
                            </div>
                            <div class="col-lg-12 form-group">
                                <label class="form-label">Comment</label>
                                <textarea class="form-control" rows="3" oninput="this.parentNode.dataset.replicatedValue = this.value" name="comment"></textarea>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="button" class="btn btn-primary waves-effect waves-light" onclick="submitLeadFormDetail('form_email')">Submit</button>
                        </div>
                        </form>
                    </div>
                    <div class="tab-pane" id="task" role="tabpanel">
                        <form id="form_task">
                            <input type="hidden" name="lead_type" value="6">
                        <div class="row">
                            <div class="col-lg-6 form-group">
                                <label class="form-label">Date</label>
                                <input class="form-control datepicker" type="text" name="date" value="">
                            </div>
                            <div class="col-lg-6 form-group">
                                <label class="form-label">Time</label>
                                <input class="form-control" type="time" name="time" value="">
                            </div>
                            <div class="col-lg-12 form-group w-full">
                                <label class="form-label">Answering User</label>
                                <select class="form-control js-example-basic-single" name="member[]">
                               <?php foreach($application_users as $uval){ ?>
                                    <option value="<?php echo $uval['id']; ?>" <?php echo $responsible == $uval['id']?"selected":"";?>><?php echo $uval['display_name']; ?></option>
                                <?php } ?>
                                </select>
                            </div>
                            <div class="col-lg-12 form-group">
                                <label class="form-label">Comment</label>
                                <textarea class="form-control" rows="3" oninput="this.parentNode.dataset.replicatedValue = this.value" name="comment"></textarea>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="button" class="btn btn-primary waves-effect waves-light" onclick="submitLeadFormDetail('form_task')">Submit</button>
                        </div>
                        </form>
                    </div>
                    <div class="tab-pane" id="meeting" role="tabpanel">
                        <form id="form_meeting">
                            <input type="hidden" name="lead_type" value="7">
                        <div class="row">
                            <div class="col-lg-6 form-group">
                                <label class="form-label">Date</label>
                                <input class="form-control datepicker" type="text" name="date" value="">
                            </div>
                            <div class="col-lg-6 form-group">
                                <label class="form-label">Time</label>
                                <input class="form-control" type="time" name="time" value="">
                            </div>
                            <div class="col-lg-12 form-group w-full">
                                <label class="form-label">Member</label>
                                <select class="form-control js-example-basic-multiple" name="member[]" multiple>
                               <?php foreach($application_users as $uval){ ?>
                                    <option value="<?php echo $uval['id']; ?>" <?php echo $responsible == $uval['id']?"selected":"";?>><?php echo $uval['display_name']; ?></option>
                                <?php } ?>
                                </select>
                            </div>
                            <div class="col-lg-12 form-group">
                                <label class="form-label">Comment</label>
                                <textarea class="form-control" rows="3" oninput="this.parentNode.dataset.replicatedValue = this.value" name="comment"></textarea>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="button" class="btn btn-primary waves-effect waves-light" onclick="submitLeadFormDetail('form_meeting')">Submit</button>
                        </div>
                        </form>
                    </div>
                    <div class="tab-pane" id="visit" role="tabpanel">
                        <form id="form_visit">
                            <input type="hidden" name="lead_type" value="8">
                        <div class="row">
                            <div class="col-lg-6 form-group">
                                <label class="form-label">Date</label>
                                <input class="form-control datepicker" type="text" name="date" value="">
                            </div>
                            <div class="col-lg-6 form-group">
                                <label class="form-label">Time</label>
                                <input class="form-control" type="time" name="time" value="">
                            </div>

                            <div class="col-lg-12 form-group">
                            <label class="form-label">Address</label>
                            <div class="grow-wrap">
                                <textarea name="address" placeholder="Address" class="border form-control" rows="3" name="address" oninput="this.parentNode.dataset.replicatedValue = this.value" ><?php echo $crm_leads['address']; ?></textarea>
                            </div>
                        </div>
                        <div class="col-lg-6 form-group w-full">
                            <label class="form-label">Country</label>
                            <select class="form-control js-example-basic-single" name="country_id" onchange="selectedcategory(this.value,'state_idd','states','country_id')">
                                <?php foreach($countries as $cval){ ?>
                                    <option value="<?php echo $cval['id']; ?>" <?php echo $crm_leads['country_id'] == $cval['id']?"selected":"";?>><?php echo $cval['country_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-lg-6 form-group w-full">
                            <label class="form-label">State</label>
                            <select class="form-control js-example-basic-single" name="state_idd" id="state_idd" onchange="selectedcategory(this.value,'city_idd','cities','state_id')">
                                <?php foreach($states as $cval){ ?>
                                    <option value="<?php echo $cval['id']; ?>" <?php echo $crm_leads['state_id'] == $cval['id']?"selected":"";?>><?php echo $cval['state_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-lg-6 form-group w-full">
                            <label class="form-label">City</label>
                            <select class="form-control js-example-basic-single" name="city_id" id="city_idd">
                                <?php foreach($cities as $cval){ ?>
                                    <option value="<?php echo $cval['id']; ?>" <?php echo $crm_leads['city_id'] == $cval['id']?"selected":"";?>><?php echo $cval['city_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-lg-6 form-group">
                            <label class="form-label">Post Code</label>
                            <input class="form-control" type="text" name="post_code" placeholder="Postal Code" value="<?php echo $crm_leads['post_code']; ?>">
                        </div>
                            <div class="col-lg-12 form-group">
                                <label class="form-label">Comment</label>
                                <textarea class="form-control" rows="3" oninput="this.parentNode.dataset.replicatedValue = this.value" name="comment"></textarea>
                            </div>
                        </div>
                        <div class="mt-2">
                            <button type="button" class="btn btn-primary waves-effect waves-light" onclick="submitLeadFormDetail('form_visit')">Submit</button>
                        </div>
                     </form>
                    </div>
                </div>
                <div class="card latest-update-card custom-scroll" style="height: 500px" id="crmleadhistories">
                    <?php include("custom_insert_crm_lead_histories.php"); ?>
                </div> 
            </div>
        </div>
        <?php } /**/ ?>




            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
       $('.back_leadsidebar-form').on('click', function() {
        var my_val = $('.pcoded').attr('vertical-placement');
        if (my_val == 'right') {
            var options = {
                direction: 'left'
            };
        } else {
            var options = {
                direction: 'right'
            };
        }
        $('.leadsidebar-form').toggle('slide', options, 500);
        $('.leadsidebar-form').css('display', 'block');
    });
</script>