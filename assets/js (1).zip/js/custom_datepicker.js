var date_format = DateFormate;
//console.log(date_format);
//var date_format = 'dd-mm-yy';
  $( function() {
    $( ".datepicker" ).datepicker({
showOn: "both",
buttonText: "<i class='ti-calendar text-dark f-20 f-w-800 m-r-10'></i>",
dateFormat: date_format,
yearRange: "-60:+10",
setDate: new Date(),
changeMonth: true,
changeYear: true,
// beforeShow: function (input, inst) {
//         var rect = input.getBoundingClientRect();
//         setTimeout(function () {
//             inst.dpDiv.css({ top: rect.top + 40, left: rect.left + 0 });
//         }, 0);
//     }
});
    $( ".datepicker1" ).datepicker({
	showOn: "both",
buttonText: "<i class='ti-calendar text-dark f-20 f-w-800 m-r-10'></i>",
        dateFormat: date_format,
        minDate: -10,
        maxDate: "+10D",
        changeMonth: true,
        changeYear: true
    });
    $( ".datepickerprevious" ).datepicker({
	showOn: "both",
buttonText: "<i class='ti-calendar text-dark f-20 f-w-800 m-r-10'></i>",
        dateFormat: date_format,
            changeMonth: true,
            changeYear: true,
            maxDate: 'today',
        });
    $( ".datepickernotprevious" ).datepicker({
	showOn: "both",
buttonText: "<i class='ti-calendar text-dark f-20 f-w-800 m-r-10'></i>",
        dateFormat: date_format,
            changeMonth: true,
            changeYear: true,
            minDate: 'today',
        });
	/* Used Leave dateramge picker*/	
	$(".startdatepicker").datepicker({
            dateFormat: date_format,
			changeMonth: true,
			buttonText: "<i class='ti-calendar text-dark f-20 f-w-800 m-r-10'></i>",
			changeYear: true,
			showOn: "both",
            onSelect: function (date) {
                var date2 = $('.startdatepicker').datepicker('getDate');
                $('.enddatepicker').datepicker('setDate', date2);
                $('.enddatepicker').datepicker('option', 'minDate', date2);
				tocheckdays();
            }
        });
        $('.enddatepicker').datepicker({
            dateFormat: date_format,
			changeMonth: true,
			buttonText: "<i class='ti-calendar text-dark f-20 f-w-800 m-r-10'></i>",
			changeYear: true,
			showOn: "both",
            onClose: function () {
                var dt1 = $('.startdatepicker').datepicker('getDate');
                console.log(dt1);
                var dt2 = $('.enddatepicker').datepicker('getDate');
                if (dt2 <= dt1) {
                    var minDate = $('.enddatepicker').datepicker('option', 'minDate');
                    $('.enddatepicker').datepicker('setDate', minDate);
                }
            }
        });
		/* Used Leave dateramge picker*/	
	

        /* Used Leave dateramge picker*/    //
        $(".rangedatepicker").each(function() {
           var seq = $(this).attr('data-id');
           console.log(seq);
            $(".startdatepicker_"+seq).datepicker({
                dateFormat: date_format,
                changeMonth: true,
                buttonText: "<i class='ti-calendar text-dark f-20 f-w-800 m-r-10'></i>",
                changeYear: true,
                showOn: "both",
                onSelect: function (date) {
                    var date2 = $('.startdatepicker_'+seq).datepicker('getDate');
                    $('.enddatepicker_'+seq).datepicker('setDate', date2);
                    $('.enddatepicker_'+seq).datepicker('option', 'minDate', date2);
                }
            });
            $('.enddatepicker_'+seq).datepicker({
                dateFormat: date_format,
                changeMonth: true,
                buttonText: "<i class='ti-calendar text-dark f-20 f-w-800 m-r-10'></i>",
                changeYear: true,
                showOn: "both",
                onClose: function () {
                    var dt1 = $('.startdatepicker_'+seq).datepicker('getDate');
                    var dt2 = $('.enddatepicker_'+seq).datepicker('getDate');
                    if (dt2 <= dt1) {
                        var minDate = $('.enddatepicker_'+seq).datepicker('option', 'minDate');
                        $('.enddatepicker_'+seq).datepicker('setDate', minDate);
                    }
                }
            });
            
            // var date2 = $('.startdatepicker_'+seq).datepicker('getDate');
            // $('.enddatepicker_'+seq).datepicker('setDate', date2);
            // $('.enddatepicker_'+seq).datepicker('option', 'minDate', date2);
         });
        /* Used Leave dateramge picker*/
		
		
});
