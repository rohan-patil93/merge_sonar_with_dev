<?php 
$transaction_table = "vendors";
$page_title = "Vendors";
$page_option = "COM_INSERT_VENDORS";
include 'views/custom_list_vendors_and_vendor_registers.php';
?>