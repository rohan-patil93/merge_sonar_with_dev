<?php
class CSRClass
{
    function insertData($get){
        global $callConfig;
        if($get['old_id'] && $get['old_id'] != '' ){
            $id = $get['old_id']; 
            $updated_date = date('Y-m-d h:i:s');
            $updated_by = $get['user_id'];

            $query = "UPDATE csr_proposal_data  SET is_active = 1 , updated_date='" . $updated_date . "', updated_by='" . $updated_by . "'  WHERE id= '". $id ."'";
            $res = $callConfig->executeQuery($query);
        }
        if ($get['rid'] != "") {
            $query = "
            INSERT INTO csr_proposal_data (
                company_id, date, institue_name, subject, about_organisation, background, thematic_area, education, env_sustian,
                health, skill_development, comu_development, other_thrust_area, SDGproposal, methodology, target_group,
                team_project, monitoring_mechanism, outcomes_expected, execution_plan, impact_assessment, financial_implications,
                budget_grand_total, total_budget_grand_total, form_a, form_a_file, form_b, form_b_file, form_c, form_c_file,
                form_d, form_d_file, form_e, form_e_file, form_f, form_f_file, payment_schedule, payment_grand_total, payment_grand_total_in_words, sustainability_plan, conclusion, trust_deed, trust_deed_remark, incorporation, incorporation_remark, csr1, csr1_remark, form12a, form12a_remark, form80g, form80g_remark, form35ac, form35ac_remark, pan, pan_remark, financial_statements, financial_statements_remark, proposal_remark,
                fcra, fcra_remark, tds_exemption, tds_exemption_remark, gst, gst_remark, reference, reference_remark,
                land_ownership, land_ownership_remark, property_card, property_card_remark, drawings, drawings_remark,
                govt_drawings, govt_drawings_remark, basis_estimate, basis_estimate_remark, stability_certificate,
                stability_certificate_remark, execution_works_plan, execution_works_plan_remark, address_registered_office,
                branches_organisation, registered_as, years_of_existence, geographical_area_of_work, expertise_areas,
                board_members, affiliated_political_religious, sources_of_funding, awards_recognition, government_funds_programs,
                projects_sustainability, blacklisted_details, empanelled_details, associated_csr_projects, total_turnover,
                staff_strength, past_projects_bpcl, staff_qualification_experience, references_past_funders,
                filled_all_information, title_of_project, formd_project_description, executing_organisation,
                organisation_address, contact_person, contact_details, organisation_experience, execution_place,
                place_reason, project_tenure, project_cost, funds_infisuite, funds_other_sources, project_objective,
                reason_infisuite, project_benefits, quantitative_1, quantitative_2, quantitative_3, quantitative_4,
                quantitative_5, qualitative_1, qualitative_2, qualitative_3, approval_requirement, similar_projects,
                bank_account_infisuite, information_true, signature, name, designation, organisation_seal, total_fy1,
                total_fy2, total_fy3, groups_data, source_income_data, tentative_payment_schedule, income_data, expenditure_data, assets_data,
                liabilities_data, project_data, tracking_data, proposal, is_active, current_status, status_date, from_date,
                to_date, created_by, created_date, updated_by, updated_date,incorporation_file, csr1_file, form12a_file, form80g_file, form35ac_file, pan_file, financial_statements_file, proposal_file, fcra_file, tds_exemption_file, gst_file, reference_file, land_ownership_file, trust_deed_file, drawings_file, govt_drawings_file, basis_estimate_file, stability_certificate_file, execution_works_plan_file, orgininaor, property_card_file, information_true_file, project_start_date, project_end_date
                )
            SELECT
            company_id, date, institue_name, subject, about_organisation, background, thematic_area, education, env_sustian,
            health, skill_development, comu_development, other_thrust_area, SDGproposal, methodology, target_group,
            team_project, monitoring_mechanism, outcomes_expected, execution_plan, impact_assessment, financial_implications,
            budget_grand_total, total_budget_grand_total, form_a, form_a_file, form_b, form_b_file, form_c, form_c_file,
            form_d, form_d_file, form_e, form_e_file, form_f, form_f_file, payment_schedule, payment_grand_total, payment_grand_total_in_words, sustainability_plan, conclusion, trust_deed, trust_deed_remark, incorporation, incorporation_remark, csr1, csr1_remark, form12a, form12a_remark, form80g, form80g_remark, form35ac, form35ac_remark, pan, pan_remark, financial_statements, financial_statements_remark, proposal_remark,
            fcra, fcra_remark, tds_exemption, tds_exemption_remark, gst, gst_remark, reference, reference_remark,
            land_ownership, land_ownership_remark, property_card, property_card_remark, drawings, drawings_remark,
            govt_drawings, govt_drawings_remark, basis_estimate, basis_estimate_remark, stability_certificate,
            stability_certificate_remark, execution_works_plan, execution_works_plan_remark, address_registered_office,
            branches_organisation, registered_as, years_of_existence, geographical_area_of_work, expertise_areas,
            board_members, affiliated_political_religious, sources_of_funding, awards_recognition, government_funds_programs,
            projects_sustainability, blacklisted_details, empanelled_details, associated_csr_projects, total_turnover,
            staff_strength, past_projects_bpcl, staff_qualification_experience, references_past_funders,
            filled_all_information, title_of_project, formd_project_description, executing_organisation,
            organisation_address, contact_person, contact_details, organisation_experience, execution_place,
            place_reason, project_tenure, project_cost, funds_infisuite, funds_other_sources, project_objective,
            reason_infisuite, project_benefits, quantitative_1, quantitative_2, quantitative_3, quantitative_4,
            quantitative_5, qualitative_1, qualitative_2, qualitative_3, approval_requirement, similar_projects,
            bank_account_infisuite, information_true, signature, name, designation, organisation_seal, total_fy1,
            total_fy2, total_fy3, groups_data, source_income_data, tentative_payment_schedule, income_data, expenditure_data, assets_data,
            liabilities_data, project_data, tracking_data, proposal, is_active, current_status, status_date, from_date,
            to_date, created_by, created_date, updated_by, updated_date,incorporation_file, csr1_file, form12a_file, form80g_file, form35ac_file, pan_file, financial_statements_file, proposal_file, fcra_file, tds_exemption_file, gst_file, reference_file, land_ownership_file, trust_deed_file, drawings_file, govt_drawings_file, basis_estimate_file, stability_certificate_file, execution_works_plan_file, orgininaor, property_card_file, information_true_file, project_start_date, project_end_date
            FROM temp_csr_proposal_data
            WHERE id = '" . $get['rid'] . "';
            ";

            $res = $callConfig->executeQuery($query);
            return $res;
        }
    }

    function getCompletedProjects($get){
        global $callConfig;
        $query = "SELECT DISTINCT c.proposal_id,  p.subject, p.date, p.total_budget_grand_total, p.name,
        (SELECT COUNT(*) 
            FROM csr_project_tracking 
            WHERE proposal_id = c.proposal_id) AS proposal_count
        FROM csr_project_tracking c
        JOIN csr_proposal_data p ON p.id = c.proposal_id
        WHERE p.tracking_status = '0' AND p.company_id='" . $get['company_id'] . "' 
        AND c.proposal_id IN (
        SELECT proposal_id
        FROM csr_project_tracking
        GROUP BY proposal_id
        HAVING COUNT(*) = SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END)
    )";
    $res = $callConfig->getAllRows($query);
    return $res;
}

function getTracckingPerentage($get)
{
    global $callConfig;
    $rid = $get['id'];
    $query = "SELECT 
    COUNT(*) AS total_rows, 
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed_count
    FROM csr_project_tracking
    WHERE proposal_id=" . $rid . " AND company_id='" . $get['company_id'] . "'";
    $res = $callConfig->getRow($query);
    return $res;
}

function getCommitteMembers($get)
{
    global $callConfig;
    $query = "SELECT au.id, au.display_name, au.user_email FROM application_user_module_roles aumr LEFT JOIN application_users au ON au.id = aumr.user_id 
    WHERE aumr.role_short_code='CSR_COMMITTEE_MEMBER'
    AND aumr.company_id='" . $get['company_id'] . "' 
    AND aumr.is_active='0'";
    $res = $callConfig->getAllRows($query);
    return $res;
}
// function getCsrData($get)
// {
//     global $callConfig;
//     $id = $get['id'];
//     $table = $get['table'];
//     $query = "SELECT cpd.* FROM transaction_approval_logs tal 
//     LEFT JOIN " . $table . " cpd ON cpd.id = tal.transaction_id 
//     WHERE tal.user_id = '" . $id . "' AND tal.transaction_table='" . $table . "'
//     AND tal.company_id='" . $get['company_id'] . "' 
//     AND cpd.is_active='0'";
//     $res = $callConfig->getAllRows($query);
//     return $res;
// }
//changing this function

    function getCsrData($get){
        global $callConfig;
        $return = array();
        $id = $get['id'] ?? '';
        $current_status = $get['current_status'] ?? '';
        $table = $get['table'] ?? '';

        $query = "SELECT cpd.id, cpd.date, cpd.project_start_date, cpd.project_end_date, cpd.subject, cpd.institue_name, cpd.created_by, cpd.total_budget_grand_total, cpd.current_status, cpd.tracking_status FROM transaction_approval_logs tal 
        LEFT JOIN csr_proposal_data cpd ON cpd.id = tal.transaction_id 
        WHERE tal.user_id = '" . $id . "' AND tal.transaction_table='csr_proposal_data'
        AND tal.company_id='" . $get['company_id'] . "' 
        AND cpd.is_active='0'";
        $total_records_query = $callConfig->getAllRows($query);
        $total_records = array();
        if (!empty($total_records_query)) {
            foreach ($total_records_query as $row) {
                $total_records[] = $row;
            }
        }
        $return['total_records'] = $total_records;

        $pending_approval_query = "SELECT cpd.id, cpd.subject, cpd.project_start_date, cpd.project_end_date, cpd.date, cpd.institue_name, cpd.created_by, cpd.total_budget_grand_total, cpd.current_status, cpd.tracking_status FROM transaction_approval_logs tal 
        LEFT JOIN csr_proposal_data cpd ON cpd.id = tal.transaction_id 
        WHERE tal.user_id = '" . $id . "' AND tal.transaction_table='csr_proposal_data'
        AND tal.response_type = 0 AND tal.previous_status = cpd.current_status
        AND tal.company_id='" . $get['company_id'] . "' 
        AND cpd.is_active='0' AND cpd.current_status='" . $current_status . "'";

        $pending_approval_query = $callConfig->getAllRows($pending_approval_query);
        $pending_approvals = array();
        if (!empty($pending_approval_query)) {
            foreach ($pending_approval_query as $row) {
                $pending_approvals[] = $row;
            }
        }

        $return['pending_approvals'] = $pending_approvals;

        $approved_by_me_query = "SELECT cpd.id, cpd.subject, cpd.project_start_date, cpd.project_end_date, cpd.date, cpd.institue_name, cpd.created_by, cpd.total_budget_grand_total, cpd.current_status, cpd.tracking_status FROM transaction_approval_logs tal 
        LEFT JOIN csr_proposal_data cpd ON cpd.id = tal.transaction_id 
        WHERE tal.user_id = '" . $id . "' AND tal.transaction_table='csr_proposal_data'
        AND tal.response_type != 0
        AND tal.company_id='" . $get['company_id'] . "' 
        AND cpd.is_active='0' ";
        $approved_by_me_query = $callConfig->getAllRows($approved_by_me_query);
        $approved_by_me = array();
        if (!empty($approved_by_me_query)) {
            foreach ($approved_by_me_query as $row) {
                $approved_by_me[] = $row;
            }
        }
        $return['approved_by_me'] = $approved_by_me;

        $approval_inprogress_query = "SELECT cpd.id, cpd.subject, cpd.project_start_date, cpd.project_end_date, cpd.date, cpd.institue_name, cpd.created_by, cpd.total_budget_grand_total, cpd.current_status, cpd.tracking_status FROM transaction_approval_logs tal 
        LEFT JOIN csr_proposal_data cpd ON cpd.id = tal.transaction_id 
        WHERE tal.user_id = '" . $id . "' AND tal.transaction_table='csr_proposal_data'
        AND tal.previous_status < cpd.current_status
        AND tal.company_id='" . $get['company_id'] . "' 
        AND cpd.is_active='0' AND cpd.current_status NOT IN ('199', '20', '0') ";
        $approval_inprogress_query = $callConfig->getAllRows($approval_inprogress_query);
        $approval_inprogress = array();
        if (!empty($approval_inprogress_query)) {
            foreach ($approval_inprogress_query as $row) {
                $approval_inprogress[] = $row;
            }
        }
        $return['approval_inprogress'] = $approval_inprogress;

        $approved_query = "SELECT cpd.id, cpd.date, cpd.subject, cpd.project_start_date, cpd.project_end_date, cpd.institue_name, cpd.created_by, cpd.total_budget_grand_total, cpd.current_status, cpd.tracking_status FROM transaction_approval_logs tal 
        LEFT JOIN csr_proposal_data cpd ON cpd.id = tal.transaction_id 
        WHERE tal.user_id = '" . $id . "' AND tal.transaction_table='csr_proposal_data'
        
        AND tal.company_id='" . $get['company_id'] . "' 
        AND cpd.is_active='0' AND cpd.current_status = '199'";
        $approved_query = $callConfig->getAllRows($approved_query);
        $approved = array();
        if (!empty($approved_query)) {
            foreach ($approved_query as $row) {
                $approved[] = $row;
            }
        }
        $return['approved'] = $approved;

        // traking queries
        $tracking_pending_query = "SELECT id, date, subject, project_start_date, project_end_date, institue_name, created_by, total_budget_grand_total,current_status, tracking_status from csr_proposal_data  
            WHERE tracking_status=0 AND id in (
            SELECT cpt.proposal_id  FROM transaction_approval_logs tal 
            LEFT JOIN csr_project_tracking cpt ON cpt.id = tal.transaction_id 
            WHERE tal.user_id = '" . $id . "' AND tal.transaction_table='csr_project_tracking'
            AND tal.response_type = 0 AND tal.previous_status = cpt.current_status
            AND tal.company_id='" . $get['company_id'] . "' 
            AND cpt.is_active='0') ";


        $tracking_pending_query = $callConfig->getAllRows($tracking_pending_query);
        $tracking_pending = array();
        if (!empty($tracking_pending_query)) {
            foreach ($tracking_pending_query as $row) {
                $tracking_pending[] = $row;
            }
        }
        $return['tracking_pending'] = $tracking_pending;

        $tracking_inprogress_query = "SELECT id, date, subject, project_start_date, project_end_date, institue_name, created_by, total_budget_grand_total,current_status, tracking_status from csr_proposal_data  
            WHERE id in (
            SELECT cpt.proposal_id  FROM transaction_approval_logs tal 
            LEFT JOIN csr_project_tracking cpt ON cpt.id = tal.transaction_id 
            WHERE tal.user_id = '" . $id . "' AND tal.transaction_table='csr_project_tracking'
            AND tal.previous_status < cpt.current_status
            AND tal.company_id='" . $get['company_id'] . "' 
            AND cpt.is_active='0') AND tracking_status = 0";

        $tracking_inprogress_query = $callConfig->getAllRows($tracking_inprogress_query);
        $tracking_inprogress = array();
        if (!empty($tracking_inprogress_query)) {
            foreach ($tracking_inprogress_query as $row) {
                $tracking_inprogress[] = $row;
            }
        }

        $return['tracking_inprogress'] = $tracking_inprogress;

        $tracking_completed_query = "SELECT id, date, subject, project_start_date, project_end_date, institue_name, created_by, total_budget_grand_total, current_status, tracking_status from csr_proposal_data  
            WHERE tracking_status=1 AND id in (
            SELECT tal.transaction_id   FROM transaction_approval_logs tal 
            WHERE tal.user_id = '" . $id . "' AND tal.transaction_table='csr_proposal_data'

            AND tal.company_id='" . $get['company_id'] . "') ";


        $tracking_completed_query = $callConfig->getAllRows($tracking_completed_query);
        $tracking_completed = array();
        if (!empty($tracking_completed_query)) {
            foreach ($tracking_completed_query as $row) {
                $tracking_completed[] = $row;
            }
        }
        $return['tracking_completed'] = $tracking_completed;

        //newly added
        $tracking_percentage_query = "SELECT proposal_id, 
                   ROUND((SUM(IF(`status` = 'completed', 1, 0)) / COUNT(id)) * 100) AS percent
            FROM csr_project_tracking 
            WHERE company_id = '" . $get['company_id'] . "' 
            AND proposal_id IN (
                SELECT cpd.id 
                FROM csr_proposal_data cpd 
                INNER JOIN transaction_approval_logs tal ON cpd.id = tal.transaction_id
                WHERE tal.user_id = '" . $id . "' 
                AND cpd.company_id = '" . $get['company_id'] . "'  
                AND cpd.is_active = 0
            ) 
            AND is_active = 0 
            GROUP BY proposal_id ";

        $tracking_percentage_query = $callConfig->getAllRows($tracking_percentage_query);
        $tracking_percentage = array();
        if (!empty($tracking_percentage_query)) {
            foreach ($tracking_percentage_query as $row) {
                $tracking_percentage[$row->proposal_id] = $row->percent;
            }
        }
        $return['tracking_percentage'] = $tracking_percentage;

        return $return;
    }
function getApprovedMembers($get)
{
    global $callConfig;
    $id = $get['id'];
    $table = $get['table'];
    $query = "SELECT au.id, au.display_name, au.user_email FROM transaction_approval_logs tal
    LEFT JOIN application_users au ON au.id = tal.user_id 
    WHERE tal.transaction_id = '" . $id . "' AND tal.transaction_table='" . $table . "'
    AND tal.company_id='" . $get['company_id'] . "' 
    AND au.is_active='0'";
    $res = $callConfig->getAllRows($query);
    return $res;
}

function getCsrSetting($get)
{
    global $callConfig;
    $id = $get['id'];
    $table = $get['table'];
    $query = "SELECT * FROM  csr_setting WHERE company_id='" . $get['company_id'] . "' AND is_active='0'";
    $res = $callConfig->getRow($query);
    return $res;
}


   // MAP Point 
function getCompaniesData($get)
{
    global $callConfig;
    $return = array();

    $countries_details = "SELECT id, country_name FROM  countries WHERE  company_id='" . $get['company_id'] . "' 
    AND  is_active =0 ";
    $countries_details = $callConfig->getAllRows($countries_details);
    $ct_details = array();
    $i = 1;
    foreach ($countries_details as $ct) {
        $ct_details[$i] = $ct;
        $i++;
    }
    $return['ct_details'] = $ct_details;

    $application_users_details = "SELECT id, display_name, user_field_work_type FROM  application_users WHERE company_id='" . $get['company_id'] . "' 
    AND is_active =0";
    $application_users_details = $callConfig->getAllRows($application_users_details);
    $application_users = array();
    $i = 1;
    foreach ($application_users_details as $agd) {
        $application_users[$i] = $agd;
        $i++;
    }
    $return['application_users'] = $application_users;

    $currencies_details = "SELECT id, concat(currency_short_code,'-', currency_name) as currency FROM  currencies WHERE  company_id='" . $get['company_id'] . "' 
    AND is_active = 0 ";
    $currencies_details = $callConfig->getAllRows($currencies_details);
    $cr_details = array();
    $i = 1;
    foreach ($currencies_details as $st) {
        $cr_details[$i] = $st;
        $i++;
    }
    $return['cr_details'] = $cr_details;

    $companies_details = "SELECT id, name  FROM  companies WHERE  company_id='" . $get['company_id'] . "' AND is_active =0 ";
    $companies_details = $callConfig->getAllRows($companies_details);
    $cmp_details = array();
    $i = 1;
    foreach ($companies_details as $st) {
        $cmp_details[$i] = $st;
        $i++;
    }
    $return['cmp_details'] = $cmp_details;

    return $return;
}

function getMapPoints($get){
    global $callConfig;
    $return = array();
    $userid = $get['userid'];
    $map_date = $get['map_date'];
    $user_field_work_type = $get['user_field_work_type'];
    if ($user_field_work_type == '1') {
        $query1 = "SELECT user_id, 	plan_date, plan_longitude as lng, plan_latitude as lat , plan_location as name  From field_work_daily_plans Where user_id='" . $userid . "' AND plan_date='" . $map_date . "' AND company_id='" . $get['company_id'] . "' AND is_active =0 ";
            // return $query1;
        $query1 = $callConfig->getAllRows($query1);
        $assignedLocations  = array();
        $i = 1;
        foreach ($query1 as $row) {
            $assignedLocations[$i] = $row;
            $i++;
        }
        $return['assignedLocations'] = $assignedLocations;
    }

    $query2 = "SELECT user_id, map_latitude as lat, map_longitude as lng, map_date, map_title as name,  map_time From field_work_user_map_points Where user_id='" . $userid . "' AND map_date='" . $map_date . "' AND company_id='" . $get['company_id'] . "' AND is_active =0 ";
    $query2 = $callConfig->getAllRows($query2);
    $visitedLocations   = array();
    $i = 1;
    foreach ($query2 as $row) {
        $visitedLocations[$i] = $row;
        $i++;
    }
    $return['visitedLocations'] = $visitedLocations;
    return $return;
}

function getFieldWorkDailyPlanData($get){
    global $callConfig;
    $return = array();
    $from_date = $get['from_date'];
    $to_date = $get['to_date'];
    $userids_string = $get['userids'];
    $managerids_string = $get['manager_ids'];
    $userids_array = explode(',', $userids_string) ?? [];

    if($managerids_string && empty($userids_string)){
        $query="SELECT id, display_name FROM application_users WHERE reports_to in (".$managerids_string.") AND company_id='".$get['company_id']. "' AND is_active =0";
        $result = $callConfig->getAllRows($query);
        if ($result) {
            foreach ($result as $row) {
                $userids_array[] = $row->id;
            }
        }
    }
    if(isset($userids_array)){
        foreach ($userids_array as $userid) {
            $query = "SELECT display_name, user_email,  user_field_work_type FROM application_users where id='" . $userid . "'";
            $res = $callConfig->getRow($query);
            if ($res->user_field_work_type == '1' || $res->user_field_work_type == '2') {
                $query1 = "SELECT fwdp.user_id AS id, au.display_name AS display_name, plan_location as  location, plan_latitude as lat ,  plan_longitude as lng,  plan_date AS from_date, '' AS to_date  
                FROM field_work_daily_plans fwdp
                JOIN application_users au on au.id = fwdp.user_id
                where user_id='".$userid."' AND plan_date BETWEEN '".$from_date."' AND '".$to_date."' AND fwdp.company_id='" . $get['company_id'] . "' AND fwdp.is_active =0
                GROUP BY fwdp.plan_date ";
                $result = $callConfig->getAllRows($query1);
                if ($result) {
                    foreach ($result as $row) {
                        $return[] = $row;
                    }
                }
            } else if($res->user_field_work_type == '3') {
            // $query1 = "SELECT user_id,  location_name as  location, work_latitude as lat, work_longitude as lng,  '" . $from_date . "' AS plan_date FROM user_field_work_details WHERE user_id='".$userid . "' AND  '".$from_date."' >= work_from_date AND '".$to_date."' <= work_to_date AND company_id='".$get['company_id'] . "' AND is_active =0 ";
                $query1="SELECT 
                ufwd.user_id AS id, 
                au.display_name AS display_name ,
                location_name AS location, 
                work_latitude AS lat, 
                work_longitude AS lng, 
                work_from_date AS from_date, 
                work_to_date AS to_date
                FROM     user_field_work_details ufwd
                JOIN application_users au on au.id = ufwd.user_id
                WHERE 
                ufwd. user_id = '".$userid . "'
                AND ufwd. company_id = '".$get['company_id'] . "'
                AND ufwd.is_active = 0
                AND (
                ('".$from_date."' BETWEEN work_from_date AND work_to_date) OR
                ('".$to_date."' BETWEEN work_from_date AND work_to_date) OR
                (work_from_date BETWEEN '".$from_date."' AND '".$to_date."') OR
                (work_to_date BETWEEN '".$from_date."' AND '".$to_date."')
            )";
            $result = $callConfig->getAllRows($query1);
            if ($result) {
                foreach ($result as $row) {
                    $return[] = $row;
                }
            }
        } 

    }
}
return $return;
}

function fetchFieldWorkDailyPlans($get)
{
    $table = $get['table'];
    $userid = $get['userid'];
    $date = $get['date'];
    global $callConfig;
    $return = array();
    if ($table == 'field_work_daily_plans') {
        $query = "SELECT *  FROM field_work_daily_plans where user_id='" . $userid . "' AND plan_date= '" . $date . "' AND company_id='" . $get['company_id'] . "' AND is_active =0 ";
        $result = $callConfig->getAllRows($query);
    } else {
        $query = "SELECT * FROM user_field_work_details WHERE user_id='" . $userid . "' AND  '" . $date . "' BETWEEN work_from_date AND work_to_date AND company_id='" . $get['company_id'] . "' AND is_active =0 ";
        $result = $callConfig->getRow($query);
    }
    if ($result) {
        $return['qeury_reslut'] = $result;
    }
    return $return;
}
function updateFieldWorkDailyPlans($get)
{
    global $callConfig;
    $rid = $get['rid'];
    $date = $get['date'];
    $table = $get['table'];
    $updated_date = date('Y-m-d h:i:s');
    $updated_by = $get['user_id'];
    if ($table == 'field_work_daily_plans') {
        $query = "UPDATE " . $table . "  SET is_active = NULL , updated_date='" . $updated_date . "', updated_by='" . $updated_by . "'  WHERE user_id= '" . $rid . "' AND plan_date = '" . $date . "'";
    } else {
        $query = "UPDATE " . $table . "  SET is_active = NULL , updated_date='" . $updated_date . "', updated_by='" . $updated_by . "'  WHERE id = '" . $rid . "'";
    }

    $res = $callConfig->executeQuery($query);
    return $res;
}

function getApplicationUsersData($get)
{
    global $callConfig;
    $return = array();
    $admin_type = $get['admin_type'];

    $whr = "";
    if($admin_type == '2'){
        $whr = "reports_to ='". $get['user_id']."' AND ";
    }elseif($admin_type == '3'){
        $whr ="id = '".$get['user_id']."' AND ";
    }
    $application_users_details = "SELECT id, display_name, user_field_work_type FROM  application_users WHERE company_id='" . $get['company_id'] . "' AND  ".$whr." is_active =0";
    $application_users_details = $callConfig->getAllRows($application_users_details);
    $application_users = array();
    $i = 1;
    foreach ($application_users_details as $agd) {
        $application_users[$i] = $agd;
        $i++;
    }
    $return['application_users'] = $application_users;

    return $return;
}

function getFieldWorkUserMapPointsData($get){
        global $callConfig;
        $return = array();
        $from_date = $get['from_date'];
        $to_date = $get['to_date'];
        $userids_string = $get['userids'];
        $userids_array = explode(',', $userids_string);

        foreach ($userids_array as $userid) {
            $query = "SELECT id,  user_field_work_type FROM application_users where id='" . $userid . "'";
            $res = $callConfig->getRow($query);
            if ($res->user_field_work_type == 1) {
                $query1 = "SELECT au.id, au.display_name, au.user_email,  au.user_field_work_type, fwump.map_date AS map_date,
                  count(DISTINCT(fwump.id)) AS vall,
                  SUM(IF( fwump.field_work_daily_plan_id = fwdp.id,1,0))  AS visited,
                  count(DISTINCT(fwump.id)) - SUM(IF( fwump.field_work_daily_plan_id = fwdp.id,1,0)) AS extra,
                  count(DISTINCT(fwdp.id)) - SUM(IF( fwump.field_work_daily_plan_id = fwdp.id,1,0)) AS pending
                FROM 
                    field_work_user_map_points fwump
                LEFT JOIN application_users au ON fwump.user_id = au.id
                LEFT JOIN 
                    field_work_daily_plans fwdp 
                    ON fwdp.user_id = fwump.user_id 
                    AND fwdp.plan_date = fwump.map_date 
                    AND fwdp.company_id = fwump.company_id 
                    AND fwdp.is_active = '0'
                WHERE 
                    fwump.user_id = '" . $userid . "'
                    AND fwump.map_date BETWEEN '" . $from_date . "' AND '" . $to_date . "'
                    AND fwump.company_id = '" . $get['company_id'] . "'
                    AND fwump.is_active = '0'
                GROUP BY 
                    fwump.user_id, fwump.map_date
                ORDER BY 
                    fwump.map_date";
            } else {
                $query1 = "SELECT au.id, au.display_name, au.user_email,  au.user_field_work_type, fwump.map_date map_date, 
                COUNT(fwump.map_date) visited, '0' as extra, '0' as pending
                FROM     application_users au
                LEFT JOIN     field_work_user_map_points fwump ON  fwump.user_id = au.id
                WHERE au.id = '" . $userid . "' AND  fwump.map_date BETWEEN '" . $from_date . "' AND '" . $to_date . "'
                    AND fwump.company_id = '" . $get['company_id'] . "'  AND fwump.is_active = '0'
                GROUP BY  au.display_name,  au.user_email, au.user_field_work_type, fwump.map_date";
            }
            //echo $query1;
            $result = $callConfig->getAllRows($query1);
            if ($result) {
                foreach ($result as $row) {
                    $return[] = $row;
                }
            }
        }
        return $return;
    }
function getUsersMapPointsData($get){
    global $callConfig;
    $date = date('Y-m-d');
    $return = array();
    $query = "SELECT t1.id, t1.user_id,au.display_name, t1.map_date, t1.map_latitude as lat, t1.map_longitude as lng, t1.map_time
    FROM field_work_user_map_points t1
    JOIN (
        SELECT user_id, MAX(id) AS max_id
        FROM field_work_user_map_points
        WHERE map_date = '".$date."' AND company_id='".$get['company_id']."' AND is_active='0'
        GROUP BY user_id, map_date
        ) t2
        ON t1.user_id = t2.user_id AND t1.id = t2.max_id
        JOIN application_users au ON au.id =  t1.user_id AND au.user_field_work_type in('1','2')";
        $result = $callConfig->getAllRows($query);
        if ($result) {
            foreach ($result as $row) {
                $return[] = $row;
            }
        }
        return $return;
    }
    function getEmployeeData($get){
        global $callConfig;
        $return = array();
        $userids_string = $get['userids'];
        $application_users_details = "SELECT id, display_name, user_field_work_type FROM  application_users WHERE reports_to in (".$userids_string.") AND company_id='" . $get['company_id'] . "' AND  is_active =0";
        // echo $application_users_details;
        $application_users_details = $callConfig->getAllRows($application_users_details);
        $return['qeury_reslut'] = $application_users_details;
        return $return;
    }

    function checkExistingData($get){
        global $callConfig;
        $return = array();
        $userid = $get['userid'];
        $date = $get['date'];
        $user_field_work_type = $get['user_field_work_type'];
        $query1 = "SELECT user_id,  plan_date, plan_longitude as lng, plan_latitude as lat , plan_location as name  From field_work_daily_plans Where user_id='" . $userid . "' AND plan_date='" . $date . "' AND company_id='" . $get['company_id'] . "' AND is_active =0 ";
        $query1 = $callConfig->getAllRows($query1);
        $assignedLocations  = array();
        $i = 1;
        foreach ($query1 as $row) {
            $assignedLocations[$i] = $row;
            $i++;
        }
        $return['assignedLocations'] = $assignedLocations;
        return $return;
    }

    // adding new function
    function getCsrProjectTracking($get){
        global $callConfig;
        $return = array();
        $proposal_id = $get['rid'];
        $query1 = "SELECT * FROM csr_project_tracking WHERE status IN ('started', 'hold', 'completed') AND proposal_id = '{$proposal_id}' GROUP BY proposal_id";
        $query1 = $callConfig->getRow($query1);
        $return['inprogress'] = $query1;

        $query2 = "SELECT * FROM csr_project_tracking WHERE (status = '' or status IS NULL) AND proposal_id = '{$proposal_id}' GROUP BY proposal_id";
        $query2 = $callConfig->getRow($query2);
        $return['pending'] = $query2;

        return $return;
    }

    function getcsrProposalData($get)
    {
        global $callConfig;
        $return = array();
        $orgininaor = $get['orgininaor'];

        $query = "SELECT * FROM  csr_proposal_data where orgininaor = '" . $orgininaor . "' AND company_id = '" . $get['company_id'] . "' AND is_active=0";
        $query_res = $callConfig->getAllRows($query);
        $csr_proposal_arr = array();
        foreach ($query_res as $row) {
            $csr_proposal_arr[] = $row;
        }
        $return['csr_proposal_arr'] = $csr_proposal_arr;

        $query1 = "SELECT proposal_id, 
        ROUND((sum(if(`status`='completed',1,0))/count(id))*100) as percent 
        FROM csr_project_tracking WHERE company_id = '" . $get['company_id'] . "' AND 
        proposal_id IN (SELECT id FROM csr_proposal_data WHERE company_id = '" . $get['company_id'] . "' AND orgininaor ='" . $orgininaor . "' AND is_active = 0) 
        AND is_active=0 GROUP BY proposal_id";

        $query1_res = $callConfig->getAllRows($query1);
        $tracking_percent_arr = array();
        foreach ($query1_res as $row) {
            $tracking_percent_arr[$row->proposal_id] = $row->percent;
        }
        $return['tracking_percent_arr'] = $tracking_percent_arr;

        $query2 = "SELECT DISTINCT proposal_id 
            FROM csr_project_tracking 
            WHERE status IN ('started', 'hold', 'completed') AND
            proposal_id IN (SELECT id FROM csr_proposal_data WHERE company_id = '" . $get['company_id'] . "' AND orgininaor = '" . $orgininaor . "' AND is_active = 0 AND current_status = 199  AND tracking_status=0)";
        $query2_res = $callConfig->getAllRows($query2);
        $tracking_inprogress = array();
        foreach ($query2_res as $row) {
            $tracking_inprogress[] = $row->proposal_id;
        }
        $return['tracking_inprogress'] = $tracking_inprogress;

        $query3 = "SELECT DISTINCT proposal_id 
            FROM csr_project_tracking 
            WHERE (status = '' OR status IS NULL) AND proposal_id IN (SELECT id FROM csr_proposal_data WHERE company_id = '" . $get['company_id'] . "' AND orgininaor = '" . $orgininaor . "' AND is_active = 0 AND current_status = 199  AND tracking_status=0)";
        $query3_res = $callConfig->getAllRows($query3);
        $tracking_pending = array();
        foreach ($query3_res as $row) {
            $tracking_pending[] = $row->proposal_id;
        }
        $return['tracking_pending'] = $tracking_pending;

        return $return;
    }

    function getAdminDashBordData($get)
    {
        global $callConfig;
        $return = array();
        $query = "SELECT id, date, subject, project_start_date, project_end_date, institue_name, created_by, total_budget_grand_total, current_status, tracking_status FROM  csr_proposal_data where  company_id = '" . $get['company_id'] . "' AND is_active=0";
        $query_res = $callConfig->getAllRows($query);
        $csr_proposal_arr = array();
        foreach ($query_res as $row) {
            $csr_proposal_arr[] = $row;
        }
        $return['csr_proposal_arr'] = $csr_proposal_arr;

        $query1 = "SELECT proposal_id, 
        ROUND((sum(if(`status`='completed',1,0))/count(id))*100) as percent 
        FROM csr_project_tracking WHERE company_id = '" . $get['company_id'] . "' AND 
        proposal_id IN (SELECT id FROM csr_proposal_data WHERE company_id = '" . $get['company_id'] . "'  AND is_active = 0) 
        AND is_active=0 GROUP BY proposal_id";

        $query1_res = $callConfig->getAllRows($query1);
        $tracking_percent_arr = array();
        foreach ($query1_res as $row) {
            $tracking_percent_arr[$row->proposal_id] = $row->percent;
        }
        $return['tracking_percent_arr'] = $tracking_percent_arr;

        $query2 = "SELECT au.id, au.display_name, au.user_email FROM application_user_module_roles aumr LEFT JOIN application_users au ON au.id = aumr.user_id 
        WHERE aumr.role_short_code='CSR_COMMITTEE_MEMBER'
        AND aumr.company_id='" . $get['company_id'] . "' 
        AND aumr.is_active='0'";

        $query2_res = $callConfig->getAllRows($query2);
        $users_arr = array();
        foreach ($query2_res as $row) {
            $users_arr[] = $row;
        }
        $return['users_arr'] = $users_arr;

        $query = "SELECT id, proposal_id, start_date, end_date, tracking_budget, status FROM  csr_project_tracking where  company_id = '" . $get['company_id'] . "' AND is_active=0 AND proposal_id IN (SELECT id FROM csr_proposal_data WHERE company_id = '" . $get['company_id'] . "'  AND is_active = 0 AND current_status = 199 AND tracking_status = 0) ";
        $budget_tracking_res = $callConfig->getAllRows($query);

        $groupedArray = array(); 

        foreach ($budget_tracking_res as $row) {
            $id = $row->proposal_id; 

            if (!isset($groupedArray[$id])) {
                $groupedArray[$id] = [];
            }
            $groupedArray[$id][] = $row;
        }
        $return['grouped_array'] = $groupedArray;

        return $return;
    }


}
?>