
<?php 
$_SESSION['apply_js']['multiselest'] = 1;
if(isset($_POST['submit_invitation'])){ 
    $_POST['company_id'] = $_SESSION['company_id'];
    $_POST['user_id'] = $_SESSION['userid'];
    $_POST['data_name'] = $_SESSION['DB_NAME'];  
    $url = API."?mode=insertapplicationuserinvitations&method=post";
    $response = file_post_contents($url, $_POST, 'insert');
    $respons = json_decode($response,1);
    $res = $respons['application_users'];
    //echo "<pre>"; print_r($respons); echo "</pre>";
  if($res['status'] == 'sucess'){ 
    $_SESSION['message'] = $_SESSION['error_message']['3000'];
    header("location:index.php?option=COM_LIST_VENDOR_INVITATIONS"); exit;
  }else{
    if(isset($_SESSION['error'][$res['error_no']])){
      $dis_err = explode(",", $res['other']);
      //print_r($dis_labels); exit;
      foreach ($dis_err as $va) {
        $dis_er [] = $dis_labels[$va];
      }
      $error_message = $res['error_no'] ." : ".$_SESSION['error'][$res['error_no']]." : ".implode(", ", (array)$dis_er);
    }else{
      $error_message = $res['message'];
    }
  }
   // echo "<pre>"; print_r($_POST);print_r($respons); echo "</pre>";
}


$getrid =  encodeId($_GET['VRRid']);
$getrid = urldecode($getrid);
$vrridary = explode(":", $getrid);
$vrrid = $vrridary['1'];
$url = API."?mode=getinvitationvendors&VRRid=".$vrrid;
$apicall = callAPI($url);
$result = json_decode($apicall,1);
$rolesres = $result['application_roles'];
$module =  $result['module_setup'];
$vendor_registration_requests =  $result['vendor_registration_requests'];
$vendor_admin_application_users =  $result['vendor_admin_application_users']; 
$vendor_hr_application_users =  $result['vendor_hr_application_users']; 
$vendor_finanace_application_users =  $result['vendor_finanace_application_users']; 
$vendor_project_application_users =  $result['vendor_project_application_users']; 
$vendor_location_application_users =  $result['vendor_location_application_users']; 
$vendor_purchase_application_users =  $result['vendor_purchase_application_users']; 
$vendor_legal_application_users =  $result['vendor_legal_application_users']; 
$vendor_types = $result['vendor_types'];
// $role_idd  =array(SUPERADMIN_ROLE,ADMIN_ROLE);
// foreach($rolesres as $rolesre){
//     if(!in_array($rolesre['role_short_code'], $role_idd)){
//         $roles[$rolesre['application_module']][] = $rolesre;
//     }
// }

$role_idd =array(BILL_VENDOR_ROLE,VMS_VENDOR_ROLE,PURCHASE_VENDOR_ROLE);
foreach($rolesres as $rolesre){
    if(in_array($rolesre['role_short_code'], $role_idd)){
        $roles[$rolesre['application_module']][] = $rolesre;
    }
}
/**
if($vendor_registration_requests['id'] !=""){
  $eventdisbale = "event_disabled";
  ?> 
  <script type="text/javascript">

    document.onreadystatechange = function () {
      if (document.readyState == "complete"){
        checkEmailidAllReadyAvilableOrNot();
        checkCompanyNameAllReadyAvilableOrNot();
    } 
  }
  </script> 
  <?php 
} **/

//echo "<pre>"; print_r($roles); echo "</pre>";
/**
$table_name = "application_users";
if(isset($_POST['submit'])){   
 $_POST['company_id'] = $_SESSION['company_id'];
 $_POST['current_status'] = 0;
 $_POST['is_active'] = 0;
 $_POST['status_date'] = nowDate();
 $_POST['from_date'] = date('Y-m-d');
 $_POST['to_date'] = date('Y-m-d');
 $_POST['display_name'] = $_POST['first_name']." ".$_POST['last_name'];

 if($_POST['submit']=='Add'){
  unset($_POST['submit']);unset($_POST['submit_value']);
  $_POST['status_date'] = nowDate();
  $_POST['created_date'] = nowDate();
  $_POST['created_by'] = $_SESSION['userid'];   
      //echo "<pre>"; print_r($_POST);exit;   
  $url = API."?mode=adddata&table=".$table_name."&method=post";
  $response = file_post_contents($url, $_POST, 'insert');

  $res = json_decode($response,1);
      //echo "<pre>"; print_r($res); echo "</pre>";
  if($res['status'] == 'sucess'){
    ?>
    <script type="text/javascript">
        document.onreadystatechange = function(){
            if(document.readyState == "complete") {
                tostarnotify('top','right','fa fa-thumbs-up','form-label label label-success','animated flipInX','animated flipOutX','<?php echo $_SESSION['error_message']['3001']; ?>','');
            } 
        }
    </script>

    <?php
    $_POST['user_id'] = $res['LASTID']; 
    $url = API."?mode=adddata&table=application_user_invitations&method=post";
    $response = file_post_contents($url, $_POST, 'insert');
}else{


}
}
}

**/
?>
<input type="hidden" id="hid_vendor_registration_requests_id" value="<?php echo $vendor_registration_requests['id']; ?>">

<script type="text/javascript" src="../assets/js/custom_insert_invite_vendor.js"></script>

<div class="card">
  <?php if($error_message !=''){ ?>
    <div class="alert alert-danger background-danger alert-dismissible">
            <strong><?php echo $error_message; ?></strong>
             <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>  
<?php } ?>
    <div class="card-header">
        <h5>Invite Vendor</h5>
        <div class="card-header-right">
            <a href="javascript:history.go(-1)" class="btn waves-effect waves-light">
                <i class="icofont icofont-reply"></i>  Back   
            </a>
        </div>
    </div>
    <div class="card-body m-r-50 m-l-50">
        <form id="send_invitation_form" method="post" > 
        <!-- <form method="post" enctype="multipart/form-data" id="send_invitation_form">  -->
            <div class="form-group row ml-20 mr-20">
                <div class="form-group col-lg-4 <?php echo $eventdisbale; ?>" >
                    <label class="form-label">Company Name&nbsp;<span class="requried">*</span></label>
                        <span class="d-block error-message text-danger"></span>
                    <input class="form-control requried_field checkCompanyNameAllReadyAvilableOrNot"  type="text"  id="company_name" name="company_name"  value="<?php echo $vendor_registration_requests['company_name']; ?>" autocomplete="off">
                     <span class="text-danger f-12 d-none" id="allreadycompanyname" >Company Name Already Register</span>
                </div>
                <div class="form-group col-lg-4 <?php echo $eventdisbale; ?>" >
                     <label class="form-label">Contact Person First Name&nbsp;<span class="requried">*</span></label>
                         <span class="d-block error-message text-danger"></span>
                     <input class="form-control requried_field"  type="text"  id="first_name" name="first_name"  value="<?php echo $vendor_registration_requests['first_name']; ?>" autocomplete="off">
                 </div>
                 <div class="form-group col-lg-4 <?php echo $eventdisbale; ?>" >
                     <label class="form-label">Contact Person Last Name &nbsp;<span class="requried">*</span></label>
                         <span class="d-block error-message text-danger"></span>
                     <input class="form-control requried_field"  type="text"  id="last_name" name="last_name"  value="<?php echo $vendor_registration_requests['last_name']; ?>" autocomplete="off">
                     <div class="d-none "style="color: red;" id="last_name_err"> Please enter Last Name </div> 
                </div>
                <div class="form-group col-lg-4 <?php echo $eventdisbale; ?>" >
                     <label class="form-label d-block">Contact Person Email Id&nbsp;<span class="requried">*</span></label>
                         <span class="d-block error-message text-danger"></span>
                        <input class="form-control allemails requried_field checkEmailidAllReadyAvilableOrNot"  type="text"  id="user_email" name="user_email" data-errorcls="repeateemailerror" data-errorcls1="validrepeateemailerror"   value="<?php echo $vendor_registration_requests['user_email']; ?>" autocomplete="off">
                    <span class="text-danger f-12 allemailerrer d-none" id="repeateemailerror" >Email Id Already Register</span>
                    <span class="text-danger f-12 allemailerrer  d-none" id="validrepeateemailerror" >Please Enter Valid Email Id</span>
                </div>
                <div class="form-group col-lg-4 <?php echo $eventdisbale; ?>" >
                    <label class="form-label">Contact Person Mobile No.</label>
                        <span class="d-block error-message text-danger"></span>
                    <div class="input-group input-icon-right">
                    <input class="form-control"  type="number"  id="user_mobile" name="user_mobile"  value="<?php echo $vendor_registration_requests['user_mobile']; ?>" autocomplete="off">
                    </div>
                </div>
                <div class="form-group col-lg-4">
                    <label class="form-label">Vendor Type</label>
                    <div class="kt-input-icon">
                        <select  name="vendor_type_id"  class="form-select js-example-basic-single">
                            <?php foreach ($vendor_types as $vendortypes) { ?>
                                <option value="<?php echo $vendortypes['id']; ?>">
                                    <?php echo $vendortypes['type_name']; ?>
                                </option>
                            <?php } ?>
                        </select>

                    </div>
                    <div class="d-none" style="color: red;" id="phone_err"> Please Vendor Type </div>
                </div>
                <div class="form-group col-lg-4">
                     <label class="form-label">Invitation Type &nbsp;<span class="requried">*</span></label>
                    <div class="form-radio">
                        <div class="radio radio-inline">
                          <label class="form-label">
                            <input type="radio" name="transaction_table" value="vendors" <?php echo $_GET['transaction_table'] == "vendors"?"checked":""; ?>>
                            <i class="helper"></i> Invite Direct Vendor
                          </label>
                        </div>
                        <div class="radio radio-inline">
                          <label class="form-label">
                            <input type="radio" name="transaction_table" value="vendor_registers" <?php echo ($_GET['transaction_table']== "" || $_GET['transaction_table']== "vendor_registers")?"checked":""; ?>>
                            <i class="helper"></i> Invite Vendor Registration Process
                          </label>
                        </div>
                    </div>


                    <input class="form-control"  type="hidden" id="role_id" name="role_id"  value="<?php echo VENDOR_ROLE; ?>">
              </div>
              <div class="form-group col-lg-8">
              </div>
                <!-- <div class="form-group col-lg-4">
                    <label class="form-label">Module Role &nbsp;<span class="requried">*</span></label>

                        <span class="d-block error-message text-danger"></span>
                     <select class="form-control js-example-basic-single requried_field" name="role_id" >
                          <?php foreach($roles as $key=>$rolesd){  ?>
                              <optgroup label="<?php echo $module[$key]; ?>">
                                <?php foreach($rolesd as $rolesr){  ?>
                                <option value="<?php echo $rolesr['role_short_code']; ?>" <?php echo VENDOR_ROLE == $rolesr['role_short_code']?"selected":""?>><?php echo $rolesr['display_name']; ?></option>
                                <?php } ?>
                              </optgroup>
                          <?php } ?>
                    </select> 
                </div>  -->
                <div class="form-group col-lg-3">
                    <label class="form-label">HR Connect</label>
                     <span class="d-block error-message text-danger"></span>
                    <select class="form-control js-example-basic-single all_connect_check" name="connect[hr_connect]" >

                    	<?php foreach($vendor_hr_application_users as $auser){  ?>
                            <option value="<?php echo $auser['id']; ?>" <?php echo $_SESSION['userid'] == $auser['id']?"selected":""?>><?php echo $auser['display_name']; ?></option>
                            <?php } ?>
                            <option value="">Not Applicable</option>
                    </select>
                </div>
                <div class="form-group col-lg-3">
                    <label class="form-label">Finance Connect</label>
                    <select class="form-control js-example-basic-single all_connect_check" name="connect[finance_connect]" >
                    	<?php foreach($vendor_finanace_application_users as $auser){  ?>
                            <option value="<?php echo $auser['id']; ?>" <?php echo $_SESSION['userid'] == $auser['id']?"selected":""?>><?php echo $auser['display_name']; ?></option>
                            <?php } ?>
                            <option value="">Not Applicable</option>
                    </select>
                </div>
                <div class="form-group col-lg-3">
                    <label class="form-label">Admin Connect</label>
                    
                    <select class="form-control js-example-basic-single all_connect_check " name="connect[admin_connect]" >
                    	<?php foreach($vendor_admin_application_users as $auser){  ?>
                            <option value="<?php echo $auser['id']; ?>" <?php echo $_SESSION['userid'] == $auser['id']?"selected":""?>><?php echo $auser['display_name']; ?></option>
                            <?php } ?>
                            <option value="">Not Applicable</option>
                    </select>
                </div>
                <div class="form-group col-lg-3">
                    <label class="form-label">Project Connect</label>
                    
                    <select class="form-control js-example-basic-single all_connect_check " name="connect[project_connect]" >
                    	<?php foreach($vendor_project_application_users as $auser){  ?>
                            <option value="<?php echo $auser['id']; ?>" <?php echo $_SESSION['userid'] == $auser['id']?"selected":""?>><?php echo $auser['display_name']; ?></option>
                            <?php } ?>
                            <option value="">Not Applicable</option>
                    </select>
                </div>
                <div class="form-group col-lg-3">
                    <label class="form-label">Location Connect</label>
                    
                    <select class="form-control js-example-basic-single all_connect_check" name="connect[location_connect]" >
                    	<?php foreach($vendor_location_application_users as $auser){  ?>
                          <option value="<?php echo $auser['id']; ?>" <?php echo $_SESSION['userid'] == $auser['id']?"selected":""?>><?php echo $auser['display_name']; ?></option>
                            <?php } ?>
                            <option value="">Not Applicable</option>
                    </select>
                </div>
                <div class="form-group col-lg-3">
                    <label class="form-label">Purchase Connect</label>
                   
                    <select class="form-control js-example-basic-single all_connect_check " name="connect[purchase_connect]" >
                      <?php foreach($vendor_purchase_application_users as $auser){  ?>
                            <option value="<?php echo $auser['id']; ?>" <?php echo $_SESSION['userid'] == $auser['id']?"selected":""?>><?php echo $auser['display_name']; ?></option>
                            <?php } ?>
                            <option value="">Not Applicable</option>
                    </select>
                </div>
                 <div class="form-group col-lg-3 <?php echo $eventdisbale; ?>" >
                    <label class="form-label">Legal Connect</label>
                   
                    <select class="form-control js-example-basic-single all_connect_check " name="connect[legal_connect]" >
                      <?php foreach($vendor_legal_application_users as $auser){ 
                        $selected = "";
                        if($vendor_registration_requests['legal_connect'] == $auser['id']){
                           $selected = "selected";
                        }elseif($vendor_registration_requests['legal_connect'] == $auser['id'] AND $vendor_registration_requests['legal_connect'] ==""){
                          $selected = "selected";
                        }
                       ?>
                          <option value="<?php echo $auser['id']; ?>" <?php echo $selected; ?>><?php echo $auser['display_name']; ?></option>
                            <?php } ?>
                            <option value="">Not Applicable</option>
                    </select>
                </div>

                
                <input type="hidden" name="user_type" value="3">
                <input  type="hidden"  id="company_name_validate" value="1">
                <input  type="hidden"  id="user_email_validate" value="1">
                <input  type="hidden"  name="vendor_registration_request_id" value="<?php echo $vrrid; ?>">
            </div>
            <div class="">
                <div class="row">
                  <span class="text-danger f-12 d-none" id="selectanyoneconnecterror" >Please Select Any One Connect</span>
                    <div class="col-lg-9">
                        <input type="hidden" name="submit_invitation" value="Add" />
                        <button type="button" class="btn btn-primary sendInvitation mr-2 disabled"   name="submit_value" value="exit" id="invitevendorbtn" ><i class="la la-check"></i>Send Invitation</button>
   <!--                      <button id="kt_login_signin_submit" class="btn btn-primary btn-shadow-hover font-weight-bold mr-2"   name="submit_value" value="continue"><i class="la la-check-circle"></i>Save & continue</button> -->
                    </div>
      <!--               <div class="col-lg-3 text-right">
                        <button type="reset" disabled="disabled" class="btn btn-danger"><i class="la la-trash"></i>Delete</button>
                    </div>  -->
                </div>
            </div>
        </form>
    </div>
</div>

