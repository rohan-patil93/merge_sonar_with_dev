<?php 
$transaction_table = "vendor_registers";
$page_title = "Vendor Registers";
$page_option = "COM_INSERT_VENDOR_REGISTERS";
include 'views/custom_list_vendors_and_vendor_registers.php';
?>