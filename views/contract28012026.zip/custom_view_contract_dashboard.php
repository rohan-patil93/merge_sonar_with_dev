<?php
$_SESSION['apply_js']['CONTRACT_DASHBOARD']  =1;
// API call to get dashboard data
$url = API . "?mode=getdashboardreact&method=get&admin_type=".$_SESSION['admin_type'];
$response = callAPI($url);
$data = json_decode($response, true);

//echo "<pre>"; print_r($data); echo "</pre>";

// Extract data arrays
$allcontracts = $data['allcontracts'] ?? [];
$allcustomers = $data['allcustomers'] ?? [];
$allvendors = $data['allvendors'] ?? [];
$allpermissions = $data['allpermissions'] ?? [];
$alldocuments = $data['alldocuments'] ?? [];
$allstatus = $data['allstatus'] ?? [];
$contracts = $data['contracts'] ?? [];
$permissions = $data['permissions'] ?? [];

// bar chart 
function countByMonth($array, $dateKey)
{
    $monthly = [];
    foreach ($array as $row) {
        if (!empty($row[$dateKey])) {
            $month = date("Y-m", strtotime($row[$dateKey]));
            if (!isset($monthly[$month])) {
                $monthly[$month] = 0;
            }
            $monthly[$month]++;
        }
    }
    return $monthly;
}

$contractsMonthly = countByMonth($allcontracts, "start_date");
$customersMonthly = countByMonth($allcustomers, "Created_Date");
$vendorsMonthly = countByMonth($allvendors, "created_date");


$allMonths = array_unique(array_merge(
    array_keys($contractsMonthly),
    array_keys($customersMonthly),
    array_keys($vendorsMonthly)
));
sort($allMonths);


$chartData = [];
foreach ($allMonths as $m) {
    $chartData[] = [
        "y" => date("M Y", strtotime($m)), // Display format: Aug 2025
        
        "customers" => $customersMonthly[$m] ?? 0,
        "vendors" => $vendorsMonthly[$m] ?? 0,
    ];
}
//"contracts" => $contractsMonthly[$m] ?? 0,
// area chart 
$contractsByParty = [];
foreach ($allcontracts as $c) {
    if (!empty($c['start_date'])) {
        $month = date("Y-m", strtotime($c['start_date']));
        if (!isset($contractsByParty[$month])) {
            $contractsByParty[$month] = ['vendor' => 0, 'customer' => 0];
        }
        if ($c['party_type'] === 'vendor') {
            $contractsByParty[$month]['vendor']++;
        } elseif ($c['party_type'] === 'customer') {
            $contractsByParty[$month]['customer']++;
        }
    }
}

$allMonthsContracts = array_keys($contractsByParty);
sort($allMonthsContracts);

$contractsOverviewData = [];
foreach ($allMonthsContracts as $m) {
    $contractsOverviewData[] = [
        "period" => date("Y-m", strtotime($m)),
        "vendor" => $contractsByParty[$m]['vendor'] ?? 0,
        "customer" => $contractsByParty[$m]['customer'] ?? 0,
    ];
}

// echo "<pre>";
// print_r($contractsOverviewData);
// echo "<pre>";



// Helper functions
function isExpired($dateString)
{
    if (!$dateString)
        return false;
    $today = new DateTime();
    $today->setTime(0, 0, 0);
    $endDate = new DateTime($dateString);
    return $endDate < $today;
}

function getContractsByExpiry($contractsList, $daysMin, $daysMax)
{
    if (!$contractsList || !is_array($contractsList))
        return [];

    $today = new DateTime();
    $filtered = [];

    foreach ($contractsList as $contract) {
        if (!$contract['end_date'])
            continue;

        $endDate = new DateTime($contract['end_date']);
        $daysLeft = ceil(($endDate->getTimestamp() - $today->getTimestamp()) / (60 * 60 * 24));

        if ($daysLeft >= $daysMin && $daysLeft <= $daysMax) {
            $filtered[] = $contract;
        }
    }

    return $filtered;
}
function calculateProgress($contract, $allpermissions, $alldocuments)
{
    $requiredFields = [
        "contract_name",
        "transaction_no",
        "party_id",
        "parent_contract_id",
        "start_date",
        "end_date",
        "description",
        "additional_notes",
        "payment_term_id",
        "termination_condition",
        "contract_status"
    ];

    $totalFields = count($requiredFields);
    $filledFields = 0;

    foreach ($requiredFields as $field) {
        if (!empty($contract[$field])) {
            $filledFields++;
        }
    }

    $contractPermissions = null;
    foreach ($allpermissions as $permission) {
        if ($permission['contract_id'] == $contract['id']) {
            $contractPermissions = $permission;
            break;
        }
    }

    $hasBasicPermissions = !empty($contractPermissions['basic_permissions']);
    $hasDocumentPermission = $hasBasicPermissions && strpos($contractPermissions['basic_permissions'], 'document') !== false;

    $baseProgress = ($filledFields / $totalFields) * 100;

    if (!$hasBasicPermissions)
        $baseProgress -= 10;
    if (!$hasDocumentPermission)
        $baseProgress -= 10;

    $documentCount = 0;
    foreach ($alldocuments as $doc) {
        if ($doc['contract_id'] == $contract['id']) {
            $documentCount++;
        }
    }

    $missingDocuments = 10 - $documentCount;
    $baseProgress -= $missingDocuments * 2;

    return max(0, round($baseProgress));
}
function filterAndSortContracts($contractsList, $partyType, $searchQuery = '', $sortConfig = ['key' => 'contract_name', 'direction' => 'asc'])
{
    $filtered = [];

    foreach ($contractsList as $contract) {
        if (strtolower($contract['party_type'] ?? '') !== strtolower($partyType))
            continue;

        if (!empty($searchQuery)) {
            $found = false;
            foreach ($contract as $value) {
                if ($value && stripos($value, $searchQuery) !== false) {
                    $found = true;
                    break;
                }
            }
            if (!$found)
                continue;
        }

        $filtered[] = $contract;
    }

    // Sort contracts
    usort($filtered, function ($a, $b) use ($sortConfig) {
        $aVal = $a[$sortConfig['key']] ?? '';
        $bVal = $b[$sortConfig['key']] ?? '';

        if (strpos($sortConfig['key'], 'date') !== false) {
            $aVal = strtotime($aVal);
            $bVal = strtotime($bVal);
        }

        $comparison = $aVal <=> $bVal;
        return $sortConfig['direction'] === 'desc' ? -$comparison : $comparison;
    });

    return $filtered;
}
function paginateArray($array, $page, $perPage)
{
    $startIndex = ($page - 1) * $perPage;
    return array_slice($array, $startIndex, $perPage);
}
$combinedIds = [];
if ($contracts) {
    foreach ($contracts as $contract) {
        $combinedIds[] = $contract['id'];
    }
}
if ($permissions) {
    foreach ($permissions as $permission) {
        $combinedIds[] = $permission['contract_id'];
    }
}
$combinedIds = array_unique($combinedIds);
$allowedContracts = [];
if ($_SESSION['admin_type'] =='1') {
    $allowedContracts = $allcontracts;
} else {
    foreach ($allcontracts as $contract) {
        if (in_array($contract['id'], $combinedIds)) {
            $allowedContracts[] = $contract;
        }
    }
}
$today = new DateTime();
$activeContracts = [];
$expiredContracts = [];
foreach ($allowedContracts as $contract) {
    if ($contract['is_active'] == 0) {
        if (!$contract['end_date'] || new DateTime($contract['end_date']) >= $today) {
            $activeContracts[] = $contract;
        }
    }

    if ($contract['end_date'] && new DateTime($contract['end_date']) < $today) {
        $expiredContracts[] = $contract;
    }
}
$filter = $_GET['filter'] ?? 'all';
$searchQuery = $_GET['search'] ?? '';
$sortKey = $_GET['sort_key'] ?? 'contract_name';
$sortDirection = $_GET['sort_direction'] ?? 'asc';
$currentPage = (int) ($_GET['page'] ?? 1);
$itemsPerPage = 15;
$sortConfig = ['key' => $sortKey, 'direction' => $sortDirection];
$filteredContracts = filterAndSortContracts($allowedContracts, "customer", $searchQuery, $sortConfig);
$vendorContracts = filterAndSortContracts($allowedContracts, "vendor", $searchQuery, $sortConfig);
if ($filter === 'active') {
    $filteredContracts = array_filter($filteredContracts, function ($contract) use ($today) {
        return !$contract['end_date'] || new DateTime($contract['end_date']) >= $today;
    });
    $vendorContracts = array_filter($vendorContracts, function ($contract) use ($today) {
        return !$contract['end_date'] || new DateTime($contract['end_date']) >= $today;
    });
} elseif ($filter === 'expired') {
    $filteredContracts = array_filter($filteredContracts, function ($contract) use ($today) {
        return $contract['end_date'] && new DateTime($contract['end_date']) < $today;
    });
    $vendorContracts = array_filter($vendorContracts, function ($contract) use ($today) {
        return $contract['end_date'] && new DateTime($contract['end_date']) < $today;
    });
}
$paginatedFilteredContracts = paginateArray($filteredContracts, $currentPage, $itemsPerPage);
$paginatedVendorContracts = paginateArray($vendorContracts, $currentPage, $itemsPerPage);
$expiringCustomerContracts = getContractsByExpiry($filteredContracts, 60, 90);
$expiringVendorContracts = getContractsByExpiry($vendorContracts, 60, 90);
$totalCustomerPages = ceil(count((array)$filteredContracts) / $itemsPerPage);
$totalVendorPages = ceil(count((array)$vendorContracts) / $itemsPerPage);


// echo"<pre> test"; 
// print_r($data); 
// echo"</pre>"; 
?>


<div class="mt-3">
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-5 g-3">
        <div class="col">
            <div class="card prod-p-card card-red">
                <div class="card-body">
                    <div class="row align-items-center m-b-30">
                        <div class="col">
                            <h6 class="m-b-5 text-white">Contracts</h6>
                            <h3 class="m-b-0 f-w-700 text-white"><?= count((array)$allowedContracts) ?></h3>
                        </div>
                        <div class="col-auto">
                            <i class="fa fa-file text-c-red f-18"></i>
                        </div>
                    </div>
                    <p class="m-b-0 text-white">Total Contracts</p>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card prod-p-card card-blue">
                <div class="card-body">
                    <div class="row align-items-center m-b-30">
                        <div class="col">
                            <h6 class="m-b-5 text-white">Active</h6>
                            <h3 class="m-b-0 f-w-700 text-white"><?= count((array)$activeContracts) ?></h3>
                        </div>
                        <div class="col-auto">
                            <i class="fa fa-check text-c-blue f-18"></i>
                        </div>
                    </div>
                    <p class="m-b-0 text-white">Total Active Contracts</p>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card prod-p-card card-yellow">
                <div class="card-body">
                    <div class="row align-items-center m-b-30">
                        <div class="col">
                            <h6 class="m-b-5 text-white">Expired</h6>
                            <h3 class="m-b-0 f-w-700 text-white"><?= count((array)$expiredContracts) ?></h3>
                        </div>
                        <div class="col-auto">
                            <i class="fa fa-times text-c-yellow f-18"></i>
                        </div>
                    </div>
                    <p class="m-b-0 text-white">Total Expired Contracts</p>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card prod-p-card card-green">
                <div class="card-body">
                    <div class="row align-items-center m-b-30">
                        <div class="col">
                            <h6 class="m-b-5 text-white">Total Customers</h6>
                            <h3 class="m-b-0 f-w-700 text-white"><?= count((array)$allcustomers) ?></h3>
                        </div>
                        <div class="col-auto">
                            <i class="fa fa-user text-c-green f-18"></i>
                        </div>
                    </div>
                    <p class="m-b-0 text-white">Total Customers</p>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card prod-p-card card-cyan">
                <div class="card-body">
                    <div class="row align-items-center m-b-30">
                        <div class="col">
                            <h6 class="m-b-5 text-dark">Total Vendors</h6>
                            <h3 class="m-b-0 f-w-700 text-dark"><?= count((array)$allvendors) ?></h3>
                        </div>
                        <div class="col-auto">
                            <i class="fa fa-user text-c-dark f-18"></i>
                        </div>
                    </div>
                    <p class="m-b-0 text-dark">Total Vendors</p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="mt-3">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h5>Monthly Overview</h5>
                </div>
                <div class="card-block">
                    <div id="morris-bar-chart"></div>
                </div>
            </div>
        </div>
        <!-- <div class="col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h5>Contracts Overview</h5>
                </div>
                <div class="card-block">
                    <div id="chart_Donut" style="width: 100%; height: 300px;"></div>
                </div>
            </div>
        </div> -->
    </div>
</div>
<ul class="nav md-tabs infisuite_tab mb-2" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" data-bs-toggle="tab" href="#customers" role="tab"><i class="ti ti-user"></i> Customers</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-bs-toggle="tab" href="#vendors" role="tab"><i class="ti ti-user"></i> Vendors</a>
    </li>
</ul>
<div class="tab-content tabs">
    <div class="tab-pane active" id="customers" role="tabpanel">
        <div class="row mt-4">
            <div class="col-lg-9">
                <div class="card">
                    <div class="card-header">
                        <h5>Customer Contracts</h5>
                        <a href="index.php?option=COM_LIST_CONTRACTS"  class=" b-b-primary text-primary float-right">View all</a>
                    </div>
                    <div class="card-body">
                        <!-- <input type="search" id="contractSearch" class="form-control my-2"
                            placeholder="Search contracts..."> -->
                        <div class="table-responsive mt-3">
                            <table class="table table-bordered" id="contractTable">
                                <tr>
                                    <th>#</th>
                                    <th>Contract</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Contract ID</th>
                                    <th>RT Number</th>
                                    <th>Invoice Number</th>
                                    <!-- <th>Status</th> -->
                                    <th>Progress</th>
                                </tr>

                                <?php if (!empty($paginatedFilteredContracts)): ?>
                                    <?php foreach ($paginatedFilteredContracts as $index => $contract): ?>
                                        <?php
                                        $expired = isExpired($contract['end_date']);
                                        $statusMatch = null;
                                        foreach ($allstatus as $status) {
                                            if ($status['name'] === $contract['contract_status']) {
                                                $statusMatch = $status;
                                                break;
                                            }
                                        }
                                        $background = $statusMatch['background_color'] ?? '#28a745';
                                        $color = $statusMatch['color'] ?? '#fff';
                                        ?>
                                        <tr>
                                            <td><?= ($currentPage - 1) * $itemsPerPage + $index + 1 ?></td>
                                            <td><a href="index.php?option=COM_INSERT_CONTRACTS&Rid=<?php echo deocdeId("id:".$contract['id']);?>" ><?= htmlspecialchars($contract['contract_name']) ?></a>
                                            </td>
                                            <td><?= fromDate($contract['start_date']) ?></td>
                                            <td>
                                                <?= fromDate($contract['end_date']) ?>
                                                <?php if ($expired): ?>
                                                    <label class="form-label label label-danger">Expired</label>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= htmlspecialchars($contract['transaction_no'] ?? 'Not Provided') ?></td>
                                            <td><?= htmlspecialchars($contract['rt_number'] ?? 'Not Provided') ?></td>
                                            <td><?= htmlspecialchars($contract['invoice_number'] ?? 'Not Provided') ?></td>
                                            <!-- <td>
                                                <label class="form-label label"
                                                    style="background: <?= $background ?>; color: <?= $color ?>;">
                                                    <?= htmlspecialchars($contract['contract_status']) ?>
                                                </label>
                                            </td> -->
                                            <td>
                                            <?php $progress = calculateProgress($contract, $allpermissions, $alldocuments); ?>
                                                <div class="progress progress-sm">
                                                    <div class="progress-bar progress-bar-warning" role="progressbar"
                                                        style="width: <?= $progress ?>%;" aria-valuenow="<?= $progress ?>"
                                                        aria-valuemin="0" aria-valuemax="100">
                                                        <?= $progress ?>%
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center">No contracts found</td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 accordion-block">
                <div class="card">
                    <div class="card-header">
                        <h5>Expiring Contracts</h5>
                    </div>
                    <div class="card-body">
                        <div id="accordion" role="tablist" aria-multiselectable="true">
                            <?php
                            $sections = [
                                ['title' => 'Expires in 7 Days', 'min' => 0, 'max' => 7, 'id' => 'collapseZero'],
                                ['title' => 'Expires in 30 Days', 'min' => 0, 'max' => 30, 'id' => 'collapseOne'],
                                ['title' => 'Expires in 31 to 60 Days', 'min' => 31, 'max' => 60, 'id' => 'collapseTwo'],
                                ['title' => 'Expires in 61-90 Days', 'min' => 61, 'max' => 90, 'id' => 'collapseThree']
                            ];
                            foreach ($sections as $index => $section):
                                $contracts = getContractsByExpiry(filterAndSortContracts($allowedContracts, "customer"), $section['min'], $section['max']);
                                ?>
                                <div class="accordion-panel mt-4">
                                    <div class="accordion-heading" role="tab" id="heading<?= $index + 1 ?>">
                                        <h3 class="card-title accordion-title p-0 bg-gray">
                                            <a class="accordion-msg waves-effect waves-dark border-0"
                                                data-bs-toggle="collapse" data-parent="#accordion"
                                                href="#<?= $section['id'] ?>"
                                                aria-expanded="<?= $index === 0 ? 'true' : 'false' ?>"
                                                aria-controls="<?= $section['id'] ?>">
                                                <?= $section['title'] ?>
                                            </a>
                                        </h3>
                                    </div>
                                    <?php
                                    $contractsWithoutRenew = array_filter($contracts, function ($contract) {
                                        return empty($contract['renew_data']);
                                    });
                                    ?>
                                    <div id="<?= $section['id'] ?>"
                                        class="panel-collapse collapse <?= $index === 0 ? 'in show' : '' ?>" role="tabpanel"
                                        aria-labelledby="heading<?= $index + 1 ?>">
                                        <div class="accordion-content accordion-desc p-0 custom-scroll" style="max-height: 300px;">
                                            <div class="table-responsive">
                                                
                                                <?php if (!empty($contractsWithoutRenew)): ?>
                                                    <table class="table table-bordered">
                                                        <tr>
                                                            <th>Contract</th>
                                                            <th>Days Left</th>
                                                            <th>End Date</th>
                                                            <th>Action</th>
                                                        </tr>
                                                        <?php  if (!empty($contracts)): ?>
                                                            <?php foreach ($contracts as $contract){ ?>
                                                                <?php
                                                                $endDate = new DateTime($contract['end_date']);
                                                                $today = new DateTime();
                                                                $daysLeft = ceil(($endDate->getTimestamp() - $today->getTimestamp()) / (60 * 60 * 24));
                                                                ?>
                                                                <tr>
                                                                    <td><a
                                                                            href="index.php?option=COM_INSERT_CONTRACTS&Rid=<?php echo deocdeId("id:".$contract['id']);?>"><?php echo htmlspecialchars($contract['contract_name']); ?></a>
                                                                    </td>
                                                                    <td><?php echo  $daysLeft; ?> Days Left</td>
                                                                    <td><label
                                                                            class="form-label label label-danger"><?php echo fromDate($contract['end_date']); ?></label>
                                                                    </td>
                                                                    <td>
                                                                        <button onclick="openRenewPage(<?php echo deocdeId('id:'.$contract['id']); ?>)" 
                                                                            class="btn btn-primary btn-sm">
                                                                            Renew
                                                                        </button>
                                                                    </td>
                                                                    
                                                                    
                                                                </tr>
                                                            <?php } ?> 
                                                        <?php endif; ?>
                                                    </table>
                                                <?php else: ?>
                                                    <table class="table table-bordered">
                                                        <tr>
                                                            <td colspan="4" class="text-center">No contracts Found</td>
                                                        </tr>
                                                    </table>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <h5 class="mt-4">Expired Contracts</h5>
                        <div id="accordionExpired" role="tablist" aria-multiselectable="true">
                            <?php
                            $expiredSections = [
                                ['title' => 'Expired last 7 Days', 'days' => 7, 'id' => 'headingZero'],
                                ['title' => 'Expired last 30 Days', 'days' => 30, 'id' => 'headingFour'],
                                ['title' => 'Expired last 60 Days', 'days' => 60, 'id' => 'headingFive'],
                                ['title' => 'Expired last 90 Days', 'days' => 90, 'id' => 'headingSix']
                            ];
                            foreach ($expiredSections as $index => $section):
                                $today = new DateTime();
                                $today->setTime(0, 0, 0);
                                $pastDate = (clone $today)->modify("-{$section['days']} days");

                                $expiredContracts = [];
                                foreach ($allowedContracts as $contract) {
                                    if (!$contract['end_date'] || strtolower($contract['party_type'] ?? '') !== 'customer')
                                        continue;
                                    $endDate = new DateTime($contract['end_date']);
                                    $endDate->setTime(0, 0, 0);
                                    if ($endDate < $today && $endDate >= $pastDate) {
                                        $expiredContracts[] = $contract;
                                    }
                                }
                                ?>
                                <div class="accordion-panel mt-4">
                                    <div class="accordion-heading" role="tab" id="<?= $section['id'] ?>">
                                        <h3 class="card-title accordion-title p-0 bg-gray">
                                            <a class="accordion-msg waves-effect waves-dark border-0"
                                                data-bs-toggle="collapse" data-parent="#accordionExpired"
                                                href="#collapseExpired<?= $index + 1 ?>"
                                                aria-expanded="<?= $index === 0 ? 'true' : 'false' ?>"
                                                aria-controls="collapseExpired<?= $index + 1 ?>">
                                                <?= $section['title'] ?> (<?= count((array)$expiredContracts) ?>)
                                            </a>
                                        </h3>
                                    </div>
                                    <div id="collapseExpired<?= $index + 1 ?>"
                                        class="panel-collapse collapse <?= $index === 0 ? 'in show' : '' ?>" role="tabpanel"
                                        aria-labelledby="<?= $section['id'] ?>">
                                        <div class="accordion-content accordion-desc p-0 custom-scroll" style="max-height: 300px;">
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <tr>
                                                        <th>Contract</th>
                                                        <th>Days Expired</th>
                                                        <th>End Date</th>
                                                    </tr>
                                                    <?php if (!empty($expiredContracts)): ?>
                                                        <?php foreach ($expiredContracts as $contract): ?>
                                                            <?php
                                                            $endDate = new DateTime($contract['end_date']);
                                                            $daysExpired = ceil(($today->getTimestamp() - $endDate->getTimestamp()) / (60 * 60 * 24));
                                                            ?>
                                                            <tr>
                                                                <td><a
                                                                        href="index.php?option=COM_INSERT_CONTRACTS&Rid=<?php echo deocdeId("id:".$contract['id']);?>"><?= htmlspecialchars($contract['contract_name']) ?></a>
                                                                </td>
                                                                <td><?= $daysExpired ?> Days Ago</td>
                                                                <td><label
                                                                        class="form-label label label-danger"><?= fromDate($contract['end_date']) ?></label>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    <?php else: ?>
                                                        <tr>
                                                            <td colspan="3" class="text-center">No contracts expired in
                                                                this
                                                                range</td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="tab-pane" id="vendors" role="tabpanel">
        <div class="row mt-4">
            <div class="col-lg-9">
                <div class="card">
                    <div class="card-header">
                        <h5>Vendor Contracts</h5>
                        <a href="index.php?option=COM_LIST_CONTRACTS"  class=" b-b-primary text-primary float-right">View all</a>
                    </div>
                    
                    <div class="card-body">
                        <!-- <input type="search" id="vendorSearch" class="form-control my-2"
                            placeholder="Search vendors..."> -->
                        <div class="table-responsive mt-3">
                            <table class="table table-bordered" id="vendorTable">
                                <tr>
                                    <th>#</th>
                                    <th>Contract</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Contract ID</th>
                                    <th>RT Number</th>
                                    <th>Invoice Number</th>
                                    <!-- <th>Status</th> -->
                                    <th>Progress</th>
                                </tr>

                                <?php if (!empty($paginatedVendorContracts)): ?>
                                    <?php foreach ($paginatedVendorContracts as $index => $contract): ?>
                                        <?php
                                        $expired = isExpired($contract['end_date']);
                                        $statusMatch = null;
                                        foreach ($allstatus as $status) {
                                            if ($status['name'] === $contract['contract_status']) {
                                                $statusMatch = $status;
                                                break;
                                            }
                                        }
                                        $background = $statusMatch['background_color'] ?? '#28a745';
                                        $color = $statusMatch['color'] ?? '#fff';
                                        ?>
                                        <tr>
                                            <td><?= ($currentPage - 1) * $itemsPerPage + $index + 1 ?></td>
                                            <td><a
                                                    href="index.php?option=COM_INSERT_CONTRACTS&Rid=<?php echo deocdeId("id:".$contract['id']);?>"><?= htmlspecialchars($contract['contract_name']) ?></a>
                                            </td>
                                            <td><?= fromDate($contract['start_date']) ?></td>
                                            <td>
                                                <?= fromDate($contract['end_date']) ?>
                                                <?php if ($expired): ?>
                                                    <label class="form-label label label-danger">Expired</label>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= htmlspecialchars($contract['transaction_no'] ?? 'Not Provided') ?></td>
                                            <td><?= htmlspecialchars($contract['rt_number'] ?? 'Not Provided') ?></td>
                                            <td><?= htmlspecialchars($contract['invoice_number'] ?? 'Not Provided') ?></td>
                                            <!-- <td>
                                                <label class="form-label label"
                                                    style="background: <?= $background ?>; color: <?= $color ?>;">
                                                    <?= htmlspecialchars($contract['contract_status']) ?>
                                                </label>
                                            </td> -->
                                            <td>
                                                <?php $progress = calculateProgress($contract, $allpermissions, $alldocuments); ?>
                                                <div class="progress progress-sm">
                                                    <div class="progress-bar progress-bar-primary" role="progressbar"
                                                        style="width: <?= $progress ?>%;" aria-valuenow="<?= $progress ?>"
                                                        aria-valuemin="0" aria-valuemax="100">
                                                        <?= $progress ?>%
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center">No vendor contracts found</td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 accordion-block">
                <div class="card">
                    <div class="card-header">
                        <h5>Expiring Contracts</h5>
                    </div>
                    <div class="card-body">
                        <div id="accordionExpiring" role="tablist" aria-multiselectable="true">
                            <?php foreach ($sections as $index => $section): ?>
                                <?php $contracts = getContractsByExpiry($vendorContracts, $section['min'], $section['max']); ?>
                                <div class="accordion-panel mt-4">
                                    <div class="accordion-heading" role="tab" id="headingExpiring<?= $index ?>">
                                        <h3 class="card-title accordion-title p-0 bg-gray">
                                            <a class="accordion-msg waves-effect waves-dark border-0"
                                                data-bs-toggle="collapse" data-parent="#accordionExpiring"
                                                href="#collapseExpiring<?= $index ?>"
                                                aria-expanded="<?= $index === 0 ? 'true' : 'false' ?>"
                                                aria-controls="collapseExpiring<?= $index ?>">
                                                <?= htmlspecialchars($section['title']) ?>
                                            </a>
                                        </h3>
                                    </div> 
                                    <?php
                                    $contractsWithoutRenew = array_filter($contracts, function ($contract) {
                                        return empty($contract['renew_data']);
                                    });
                                    ?>
                                    <div id="collapseExpiring<?= $index ?>"
                                        class="panel-collapse collapse <?= $index === 0 ? 'show' : '' ?>" role="tabpanel"
                                        aria-labelledby="headingExpiring<?= $index ?>">
                                        <div class="accordion-content accordion-desc p-0 custom-scroll" style="max-height: 300px;">
                                            <div class="table-responsive">
                                                <?php if (!empty($contractsWithoutRenew)): ?>
                                                    <table class="table table-bordered">
                                                        <tr>
                                                            <th>Contract</th>
                                                            <th>Days Left</th>
                                                            <th>End Date</th>
                                                            <th>Action</th>
                                                        </tr>
                                                        <?php if (!empty($contracts)): ?>
                                                            <?php foreach ($contracts as $contract): ?>
                                                                <?php
                                                                $endDate = new DateTime($contract['end_date']);
                                                                $today = new DateTime();
                                                                $daysLeft = ceil(($endDate->getTimestamp() - $today->getTimestamp()) / (60 * 60 * 24));
                                                                ?>
                                                                <tr>
                                                                    <td><a
                                                                            href="index.php?option=COM_INSERT_CONTRACTS&Rid=<?php echo deocdeId("id:".$contract['id']);?>"><?= htmlspecialchars($contract['contract_name']) ?></a>
                                                                    </td>
                                                                    <td><?= $daysLeft ?> Days Left</td>
                                                                    <td><span
                                                                            class="badge bg-danger text-white"><?= fromDate($contract['end_date']) ?></span>
                                                                    </td>
                                                                    <td>
                                                                        <button onclick="openRenewPage(<?= decodeId('id:' . $contract['id']); ?>)" 
                                                                            class="btn btn-primary btn-sm">
                                                                            Renew
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; ?> 
                                                        <?php endif; ?>
                                                    </table>
                                                <?php else: ?>
                                                    <table class="table table-bordered">
                                                        <tr>
                                                            <td colspan="4" class="text-center">No contracts Found</td>
                                                        </tr>
                                                    </table>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Expired Contracts -->
                        <h5 class="mt-4">Expired Contracts</h5>
                        <div id="accordionExpired" role="tablist" aria-multiselectable="true">
                            <?php foreach ($expiredSections as $index => $section): ?>
                                <?php
                                $today = new DateTime();
                                $today->setTime(0, 0, 0);
                                $pastDate = clone $today;
                                $pastDate->modify("-{$section['days']} days");

                                $expiredContracts = [];
                                foreach ($allowedContracts as $contract) {
                                    if (!$contract['end_date'] || strtolower($contract['party_type'] ?? '') !== 'vendor')
                                        continue;
                                    $endDate = new DateTime($contract['end_date']);
                                    $endDate->setTime(0, 0, 0);
                                    if ($endDate < $today && $endDate >= $pastDate) {
                                        $expiredContracts[] = $contract;
                                    }
                                }
                                ?>
                                <div class="accordion-panel mt-4">
                                    <div class="accordion-heading" role="tab" id="headingExpired<?= $index ?>">
                                        <h3 class="card-title accordion-title p-0 bg-gray">
                                            <a class="accordion-msg waves-effect waves-dark border-0"
                                                data-bs-toggle="collapse" data-parent="#accordionExpired"
                                                href="#collapseExpired<?= $index ?>"
                                                aria-expanded="<?= $index === 0 ? 'true' : 'false' ?>"
                                                aria-controls="collapseExpired<?= $index ?>">
                                                <?= htmlspecialchars($section['title']) ?>
                                                (<?= count((array)$expiredContracts) ?>)
                                            </a>
                                        </h3>
                                    </div>
                                    <div id="collapseExpired<?= $index ?>" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="headingExpired<?= $index ?>">
                                        <div class="accordion-content accordion-desc p-0 custom-scroll" style="max-height: 300px;">
                                            <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <tr>
                                                        <th>Contract</th>
                                                        <th>Days Expired</th>
                                                        <th>End Date</th>
                                                    </tr>
                                                    <?php if (!empty($expiredContracts)): ?>
                                                        <?php foreach ($expiredContracts as $contract): ?>
                                                            <?php
                                                            $endDate = new DateTime($contract['end_date']);
                                                            $daysExpired = ceil(($today->getTimestamp() - $endDate->getTimestamp()) / (60 * 60 * 24));
                                                            ?>
                                                            <tr>
                                                                <td><a
                                                                        href="index.php?option=COM_INSERT_CONTRACTS&Rid=<?php echo deocdeId("id:".$contract['id']);?>"><?= htmlspecialchars($contract['contract_name']) ?></a>
                                                                </td>
                                                                <td><?= $daysExpired ?> Days Ago</td>
                                                                <td><span
                                                                        class="badge bg-danger text-white"><?= fromDate($contract['end_date']) ?></span>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    <?php else: ?>
                                                        <tr>
                                                            <td colspan="3" class="text-center">No contracts expired in
                                                                this
                                                                range</td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /** ?>
<div class="card">
    <div class="card-header">
        <h5>Progress Bar With Percentage</h5>
    </div>
    <div class="card-body">
        <div class="row">

            <!-- Customer Contracts Accordion -->
            <div class="col-lg-6">
                <div id="accordionCustomer" role="tablist" aria-multiselectable="true">
                    <div class="accordion-panel mt-4">
                        <div class="accordion-heading" role="tab" id="headingCustomer">
                            <h3 class="card-title accordion-title p-0 bg-gray">
                                <a class="accordion-msg waves-effect waves-dark border-0" data-bs-toggle="collapse"
                                    data-bs-parent="#accordionCustomer" href="#collapseCustomer" aria-expanded="true"
                                    aria-controls="collapseCustomer">
                                    Customer Contracts (<?= count((array)$filteredContracts) ?>)
                                </a>
                            </h3>
                        </div>
                        <div id="collapseCustomer" class="panel-collapse collapse show" role="tabpanel"
                            aria-labelledby="headingCustomer">
                            <div class="accordion-content accordion-desc p-0">
                                <?php if (!empty($filteredContracts)): ?>
                                    <?php foreach ($filteredContracts as $contract): ?>
                                        <?php $progress = calculateProgress($contract, $allpermissions, $alldocuments); ?>
                                        <div class="mt-3">
                                            <h5><?= htmlspecialchars($contract['contract_name']) ?></h5>
                                            <div class="progress progress-sm">
                                                <div class="progress-bar progress-bar-warning" role="progressbar"
                                                    style="width: <?= $progress ?>%;" aria-valuenow="<?= $progress ?>"
                                                    aria-valuemin="0" aria-valuemax="100">
                                                    <?= $progress ?>%
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-muted">No customer contracts found</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Vendor Contracts Accordion -->
            <div class="col-lg-6">
                <div id="accordionVendor" role="tablist" aria-multiselectable="true">
                    <div class="accordion-panel mt-4">
                        <div class="accordion-heading" role="tab" id="headingVendor">
                            <h3 class="card-title accordion-title p-0 bg-gray">
                                <a class="accordion-msg waves-effect waves-dark border-0" data-bs-toggle="collapse"
                                    data-bs-parent="#accordionVendor" href="#collapseVendor" aria-expanded="true"
                                    aria-controls="collapseVendor">
                                    Vendor Contracts (<?= count((array)$vendorContracts) ?>)
                                </a>
                            </h3>
                        </div>
                        <div id="collapseVendor" class="panel-collapse collapse show" role="tabpanel"
                            aria-labelledby="headingVendor">
                            <div class="accordion-content accordion-desc p-0">
                                <?php if (!empty($vendorContracts)): ?>
                                    <?php foreach ($vendorContracts as $contract): ?>
                                        <?php $progress = calculateProgress($contract, $allpermissions, $alldocuments); ?>
                                        <div class="mt-3">
                                            <h5><?= htmlspecialchars($contract['contract_name']) ?></h5>
                                            <div class="progress progress-sm">
                                                <div class="progress-bar progress-bar-primary" role="progressbar"
                                                    style="width: <?= $progress ?>%;" aria-valuenow="<?= $progress ?>"
                                                    aria-valuemin="0" aria-valuemax="100">
                                                    <?= $progress ?>%
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-muted">No vendor contracts found</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php **/ ?>
<script>
    var BarData = <?php echo json_encode($chartData); ?>;
    var AreaData = <?php echo json_encode($contractsOverviewData); ?>;

    // function setupTableSearch(inputId, tableId) {
    //     const input = document.getElementById(inputId);
    //     const table = document.getElementById(tableId);
    //     input.addEventListener("keyup", function () {
    //         const filter = input.value.toLowerCase();
    //         const rows = table.getElementsByTagName("tr");
    //         for (let i = 1; i < rows.length; i++) { // skip header
    //             const cells = rows[i].getElementsByTagName("td");
    //             let match = false;
    //             for (let j = 0; j < cells.length; j++) {
    //                 if (cells[j].innerText.toLowerCase().indexOf(filter) > -1) {
    //                     match = true;
    //                     break;
    //                 }
    //             }
    //             rows[i].style.display = match ? "" : "none";
    //         }
    //     });
    // }

    // setupTableSearch("vendorSearch", "vendorTable");
    // setupTableSearch("contractSearch", "contractTable");
</script>
<script>
    function openRenewPage(contractId) {
        var currentUrl = window.location.href;
        currentUrl = currentUrl.replace(/([?&])renew=.*?(&|$)/i, '$1');
        currentUrl = currentUrl.replace(/([?&])Rid=.*?(&|$)/i, '$1');
        currentUrl = currentUrl.replace(/([?&])option=.*?(&|$)/i, '$1'); 
        var separator = currentUrl.includes('?') ? '&' : '?';
        var newUrl = currentUrl + separator + 'option=COM_INSERT_CONTRACTS&renew=Y&Rid=' + contractId; 
        window.location.href = newUrl;
    }
</script>